# Sagas Guide

> Side effect management with redux-saga generators.

## Table of Contents

1. [What are Sagas?](#what-are-sagas)
2. [Core Effects](#core-effects)
3. [Saga Patterns](#saga-patterns)
4. [Selector Channel Effects](#selector-channel-effects)
5. [Debounce Saga](#debounce-saga)
6. [Retry and Timeout Helpers](#retry-and-timeout-helpers)
7. [Async Generator Streams](#async-generator-streams)
8. [Saga Manager (Auto-Restart)](#saga-manager)
9. [Error Handling](#error-handling)
10. [Rules and Best Practices](#rules-and-best-practices)

## What are Sagas?

Sagas are long-running generator functions that handle side effects: API calls, persistence, timers, event listeners, and complex async workflows. They listen for actions and can dispatch new actions.

This package uses `typed-redux-saga` for type-safe saga effects.

**Why sagas?**

- Keep reducers pure — no side effects in state transitions
- Declarative effects — easy to test and reason about
- Cancellation support — `takeLatest` automatically cancels previous runs
- Complex orchestration — coordinate multi-step workflows

## Core Effects

All effects are imported from `typed-redux-saga`:

```typescript
import { call, put, select, take, takeEvery, takeLatest,
         fork, delay, race, all } from "typed-redux-saga";
```

### `takeEvery` — Handle Every Action

Spawns a new task for **each** matching action:

```typescript
yield* takeEvery(fetchItems, function* (action) {
  const items = yield* call(api.fetchItems, action.payload[0]);
  yield* put(setItems(items));
});
```

### `takeLatest` — Cancel Previous, Handle Latest

Cancels any previous running task when a new action arrives:

```typescript
yield* takeLatest(searchQuery, function* (action) {
  yield* delay(300); // Natural debounce
  const results = yield* call(api.search, action.payload[0]);
  yield* put(setResults(results));
});
```

### `call` — Call a Function

Calls a function and waits for its return value:

```typescript
const result = yield* call(myFunction, arg1, arg2);
const data = yield* call([obj, obj.method], arg1); // Method call
```

### `put` — Dispatch an Action

```typescript
yield* put(setItems(items));
```

### `select` — Read State

```typescript
// Use named selectors with .effect()
const count = yield* selectItemCount.effect();
const item = yield* selectItemById.effect(itemId);
```

### `take` — Wait for a Specific Action

```typescript
const action = yield* take(submitForm);
// Execution pauses until submitForm is dispatched
```

### `fork` — Non-Blocking Task

```typescript
const task = yield* fork(backgroundWorker);
// Continues immediately; task runs in background
```

### `delay` — Wait for Time

```typescript
yield* delay(1000); // Wait 1 second
```

### `race` — First to Finish Wins

```typescript
const { response, timeout } = yield* race({
  response: call(api.fetchData),
  timeout: delay(5000),
});
if (timeout) {
  yield* put(fetchTimedOut());
}
```

### `all` — Run in Parallel

```typescript
const [users, posts] = yield* all([
  call(api.fetchUsers),
  call(api.fetchPosts),
]);
```

**Note:** Action creators can be passed directly to `takeEvery`, `takeLatest`, `takeLeading`, and `take`. No need for `.type`.

## Saga Patterns

### Polling

```typescript
function* pollData() {
  while (true) {
    yield* put(fetchData());
    yield* delay(5000);
  }
}
```

### Multi-Step Workflow

```typescript
function* wizard() {
  yield* takeEvery(startWizard, function* () {
    yield* put(showStep1());
    yield* take(step1Complete);
    yield* put(showStep2());
    yield* take(step2Complete);
    yield* put(wizardDone());
  });
}
```

### Debounce with takeLatest

```typescript
function* debounceSearch() {
  yield* takeLatest(searchInput, function* (action) {
    yield* delay(300);
    const results = yield* call(api.search, action.payload[0]);
    yield* put(setResults(results));
  });
}
```

## Selector Channel Effects

React to **selector value changes** in sagas. These handle channel lifecycle automatically.

**Public API:** `svelte-redux-toolkit/saga`

### `takeLatestFromSelector` — Most Common

Cancel previous worker when a new value arrives:

```typescript
import { takeLatestFromSelector } from "svelte-redux-toolkit/saga";

function* watchCurrentItem() {
  yield* takeLatestFromSelector(selectCurrentItemId, function* ({ payload, prevPayload }) {
    if (payload) {
      yield* put(loadItemData(payload));
    }
  });
}
```

### `takeEveryFromSelector` — Spawn for Each Change

```typescript
import { takeEveryFromSelector } from "svelte-redux-toolkit/saga";

function* watchAllChanges() {
  yield* takeEveryFromSelector(selectSomeValue, function* ({ payload }) {
    yield* call(handleChange, payload);
  });
}
```

### `takeLeadingFromSelector` — Ignore While Running

```typescript
import { takeLeadingFromSelector } from "svelte-redux-toolkit/saga";

function* watchWithThrottle() {
  yield* takeLeadingFromSelector(selectSomeValue, function* ({ payload }) {
    yield* call(expensiveOperation, payload);
  });
}
```

### With Selector Arguments

Pass arguments as the second parameter:

```typescript
yield* takeLatestFromSelector(selectItemById, [itemId], function* ({ payload }) {
  // Reacts when the specific item changes
});
```

### `createChannelFromSelector` — Complex Patterns

For patterns that don't fit `takeEvery`/`takeLatest`/`takeLeading` (e.g., races, conditional loops):

```typescript
import { createChannelFromSelector } from "svelte-redux-toolkit/saga";

function* complexWatcher() {
  const channel = yield* createChannelFromSelector(mySelector);

  // Always use try/finally to ensure channel cleanup
  try {
    while (true) {
      const { payload, prevPayload } = yield* take(channel);
      // Complex logic...
    }
  } finally {
    channel.close();
  }
}

// With arguments
function* watchSpecificItem(itemId: string) {
  const channel = yield* createChannelFromSelector(selectItemById, itemId);
  try {
    const { channelEvent, cancelled } = yield* race({
      channelEvent: take(channel),
      cancelled: take(cancelAction),
    });
    // ...
  } finally {
    channel.close();
  }
}
```

**⚠️ Always close channels in **`finally`** blocks** to prevent memory leaks.

## Debounce Saga

The `debounceSaga` utility from `svelte-redux-toolkit/saga` provides action-level debouncing with support for multiple independent debounce keys:

```typescript
import { createAction } from "svelte-redux-toolkit/utils/store/create-action";
import { debounceSaga } from "svelte-redux-toolkit/saga";

// Define a wrapper action
const debounceAction = createAction<[StoreAction<any>]>("mySlice/debounce");

export function* mySaga() {
  yield* debounceSaga(debounceAction, 300);
}

// Usage: wrap any action in the debounce action
dispatch(debounceAction(savePreferences(newPrefs)));
dispatch(debounceAction(updateSearch(query)));
// Each inner action type is debounced independently
```

## Retry and Timeout Helpers

Use `retryWithTimeout` when a saga operation may fail transiently but should not retry forever. It retries the provided saga function up to `maxRetries`, races all attempts against one overall timeout, and returns an explicit outcome string.

```typescript
import { call, put } from "typed-redux-saga";
import { retryWithTimeout } from "svelte-redux-toolkit/saga";

function* syncRemoteState() {
  const outcome = yield* retryWithTimeout(
    function* () {
      yield* call(api.syncRemoteState);
    },
    { maxRetries: 2, timeoutMs: 30_000, getDelayMs: (attempt) => 500 * (attempt + 1) }
  );

  if (outcome !== "success") {
    yield* put(syncFailed(outcome));
  }
}
```

Outcomes are `"success"`, `"retries-exhausted"`, and `"timeout"`. Keep the retried function idempotent because each retry starts it from scratch.

## Async Generator Streams

Use `wrapStreamingGenerator` to consume an `AsyncGenerator` from saga code. It forwards yielded chunks, forwards a non-null final return value, supports an optional timeout, and rethrows stream errors after calling an optional package-local `onError` callback. It intentionally has no Sentry or Electron dependency.

```typescript
import { put } from "typed-redux-saga";
import { wrapStreamingGenerator } from "svelte-redux-toolkit/saga";

function* consumeStream(stream: AsyncGenerator<MessageChunk, void, unknown>) {
  yield* wrapStreamingGenerator(
    stream,
    function* (chunk) {
      yield* put(messageChunkReceived(chunk));
    },
    { timeoutMs: 30_000, onError: (error) => reportStreamError(error) }
  );
}
```

## Saga Manager

The package saga manager (`src/slices/saga-manager/sagas/manager.ts`) provides automatic crash recovery for app-owned sagas. Register only your app sagas with `store.registerSagas(sagasMap)` before `store.init()`; `Store` starts the internal manager during initialization and does not add it to the Store saga registry, so `getSagas()` and `getSagaNames()` expose only app-owned sagas.

### Auto-Restart with Exponential Backoff

When a saga throws an unhandled error, the manager:

1. Catches the error and logs it
2. Records the crash in the saga's in-memory status record and dispatches a serialized crash report for Redux state
3. Waits with exponential backoff: 1s → 2s → 4s → 8s → ... (max 10 minutes)
4. Restarts the saga automatically
5. If the saga stabilizes (runs for >1 minute without crashing), the restart counter gradually decreases

### Reference Counting

Multiple overlapping `store.runSaga(name)` calls for the same saga name share the saga. The saga only stops when **every** returned cancel function has been invoked. This prevents accidental saga stops when components remount during navigation.

Full Store teardown is broader than a per-saga cancel: `store.dispose()` and the disposer returned by `store.init()` tear down the initialized Store runtime and stop saga tasks owned by that Store. Use the `store.runSaga(name)` cancel function for normal mount- or operation-scoped saga lifetimes; reserve `store.dispose()` for ending the whole Store lifetime.

### Crash Status

Saga crash history is tracked internally by the package-owned manager so crashed sagas can restart with backoff. The raw manager status record types are internal implementation details and are not part of the public package API.

The package also stores serializable crash reports in its internal saga-manager reducer, keyed by saga name. Each report contains a primitive timestamp and a plain error object so the data can be safely kept in Redux state or app-level state persistence:

```typescript
type SagaCrashReports = {
  reports: Array<{
    crashedAtTs: number;
    error: { name: string; message: string; stack?: string };
  }>;
  omittedCount: number;
};
```

Crash persistence is driven by package-owned actions:

- `addCrash(sagaName, report)` appends the serialized report only to that saga name's entry.
- Each saga keeps the newest 100 visible reports. When adding a crash would exceed the cap, older reports are trimmed and `omittedCount` increases by the number trimmed.
- `clearCrashes(sagaName)` removes that saga name's crash entry. Clearing one saga does not affect reports stored for other saga names.

These actions and the reducer state path are package internals unless they are intentionally exported through a public entrypoint in a future release. App code should not import internal saga-manager files or depend on the reserved internal state shape; use documented public Store and saga APIs for application lifecycle behavior.

## Error Handling

### In Saga Workers

Wrap individual workers in try/catch:

```typescript
function* handleFetchItems(action: ReturnType<typeof fetchItems>) {
  try {
    const items = yield* call(api.fetchItems, action.payload[0]);
    yield* put(fetchItems.success({ items }));
  } catch (error) {
    yield* put(fetchItems.failure(error instanceof Error ? error : new Error(String(error))));
  }
}
```

### Async Action Error Flow

With `createAsyncAction`, use `.success` and `.failure` sub-actions:

```typescript
export function* mySaga() {
  yield* takeEvery(fetchItems, function* (action) {
    try {
      const result = yield* call(api.fetch, action.payload[0]);
      yield* put(action.success(result));
    } catch (e) {
      yield* put(action.failure(e instanceof Error ? e : new Error(String(e))));
    }
  });
}
```

### Channel Cleanup

Always close channels in `finally` blocks:

```typescript
function* watchChannel() {
  const channel = yield* createChannelFromSelector(mySelector);
  try {
    // ... use channel
  } finally {
    channel.close(); // Prevents memory leaks
  }
}
```

## Rules and Best Practices

1. **Always use named selectors** — Never use `yield* select((state) => ...)` inline lambdas. Create a selector and use `.effect()`.
2. **Pass action creators directly** — `yield* takeEvery(myAction, handler)`, not `takeEvery(myAction.type, handler)`.
3. **Keep workers focused** — One concern per worker function. Compose by forking multiple watchers from a root saga.
4. **Use **`takeLatest`** for user-triggered actions** — Prevents stale responses from overwriting newer ones.
5. **Use **`call()`** for testability** — Wrap function calls in `yield* call(fn, args)` so they can be mocked in tests.
6. **Register sagas with the Store** — Call `store.registerSagas({ ... })` with app sagas before `store.init()`. Registration alone does not start the saga.
7. **Start sagas explicitly by name** — `store.init()` does not auto-start registered sagas. Call `store.runSaga(name)` from the configured Store instance. In layouts/components, call it from `onMount` and return the cancel function for mount-scoped cleanup. It takes a registered saga name only.

```svelte
<script lang="ts">
  import { onMount } from "svelte";
  import { store } from "$lib/store";

  onMount(() => store.runSaga("todosSaga"));
</script>
```

```ts
// Imperative — returns a cancel function that stops the saga.
const cancel = store.runSaga("todosSaga");
cancel();
```
