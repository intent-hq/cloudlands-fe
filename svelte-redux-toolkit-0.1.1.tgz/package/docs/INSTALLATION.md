# Installation, Cleanup, and Validation

This package has two install contexts with different expectations: consumer apps install it from npm, while maintainers validate this repository from a clean checkout.

## Consumer install

Install the package and its required peer dependencies in a Svelte 5 project:

```bash
npm install svelte-redux-toolkit redux redux-saga typed-redux-saga fast-equals
```

`svelte@^5` is also required as a peer dependency and is normally already present in a Svelte app. For saga tests that follow this repository's examples, install the optional test helper:

```bash
npm install -D redux-saga-test-plan
```

## Postinstall skill copy

When installed as a dependency under `node_modules`, `svelte-redux-toolkit` runs `scripts/postinstall.mjs`. The script:

- changes to the consuming project root before doing any project writes;
- copies packaged AI skills into the consuming project root at `.agents/skills/`;
- removes stale package-owned files from previous package versions before copying current packaged skills;
- preserves unrelated project or third-party skills under `.agents/skills/`;
- excludes generated package artifacts such as `skills/_artifacts`;
- no-ops when the package is not installed under a consumer `node_modules` directory;
- logs warnings instead of failing the install.

This side effect is intentional so humans and AI agents can discover and load the same package-specific implementation guidance after install.

## Consumer package CLI

Consuming apps should run package maintenance commands from the app root after the package has been installed and its bin has been linked. The most direct check is the installed bin path; it should print help immediately. Standard npm package invocation forms are also supported when npm can resolve the installed local bin:

```bash
./node_modules/.bin/svelte-redux-toolkit help
npm exec -- svelte-redux-toolkit help
npx svelte-redux-toolkit
npx svelte-redux-toolkit help
npx svelte-redux-toolkit install-skills
npx svelte-redux-toolkit cleanup-skills
npx svelte-redux-toolkit validate-architecture
npx svelte-redux-toolkit validate-skill-examples
```

Running `npx svelte-redux-toolkit` with no command prints the same help text. Use `install-skills` when an agent or developer needs to copy or refresh packaged AI skills in `.agents/skills/` in a consuming app. It removes stale package-owned files before copying current packaged skills and leaves unrelated skills alone. Use `cleanup-skills` to remove package-owned copied `.agents/skills/` folders before uninstalling. Both maintenance commands print copied, updated, skipped, removed, or no-op output so they should not appear silent. Use `validate-architecture` from the app root to run the packaged architecture validator against app code; use `validate-skill-examples` when validating app-local Markdown skill/doc examples.

If npm package invocation appears to do nothing, verify `./node_modules/.bin/svelte-redux-toolkit` exists in the consuming app and run `./node_modules/.bin/svelte-redux-toolkit help` directly. If that file is missing, the package is not installed or the package manager has not linked its bin in that app; reinstall or repair the local package install before retrying. In this repository's source checkout, `npx`/`npm exec` package-name invocations are not a valid smoke test because the package bin is not linked automatically; use `node scripts/cli.mjs help` for source-checkout validation.

## Explicit cleanup and uninstall

npm 7+ does not run dependency uninstall lifecycle scripts, so uninstalling the package does not automatically remove copied skill files. Run cleanup first, then uninstall:

```bash
npm uninstall svelte-redux-toolkit
npm uninstall redux redux-saga typed-redux-saga fast-equals # only if your app no longer uses them
```

The package keeps a cleanup command for package-owned files copied into `.agents/skills/`:

```bash
npx svelte-redux-toolkit cleanup-skills
# or: npm exec -- svelte-redux-toolkit cleanup-skills
```

That helper removes package-owned copied skills and leaves unrelated `.agents/skills` content alone. Remove optional test dependencies only if your app does not use them elsewhere:

```bash
npm uninstall -D redux-saga-test-plan
```

If an older package has already been uninstalled, manually remove only package-owned legacy skill folders you no longer need:

- `.agents/skills/svelte-redux-toolkit`
- `.agents/skills/init-svelte-redux-toolkit`
- `.agents/skills/redux-saga`
- `.agents/skills/migrate-to-svelte-redux-toolkit`

Do not delete `.agents/skills` as a whole unless you are certain it contains no project or third-party skills you want to keep.

## Maintainer validation

Maintainers should validate from the repository root with the committed npm lockfile:

```bash
npm ci
npm run validate:architecture
npm run validate:skill-examples
npm test
npm run build
npm run validate:release
```

Use `npm ci` for a clean local dependency baseline. Do not substitute consumer install, uninstall, or package CLI commands for release validation; those commands exercise a downstream app workflow and may update copied `.agents/skills/` content outside the repository validation path.

Run `npm run validate:architecture` before accepting or releasing changes that
touch Redux state, actions, selectors, sagas, or the skills/docs governing those areas. A
passing architecture gate exits 0 and prints
`[architecture-validation] no architecture gate violations found`; any listed
violation must be fixed or justified with the documented gate ignore comments
before release validation can pass.