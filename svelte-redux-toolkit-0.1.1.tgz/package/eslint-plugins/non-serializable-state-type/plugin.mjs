import { staticString, traverse, typeName } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "non-serializable-state-type";

const forbiddenTypes = new Set(["Date", "Map", "Set", "WeakMap", "WeakSet", "RegExp", "Promise", "Function", "Error", "Symbol"]);

function isStateShape(declaration) {
  return ["TSInterfaceDeclaration", "TSTypeAliasDeclaration"].includes(declaration?.type) && declaration.id?.name?.endsWith("State");
}

function stateMembers(declaration) {
  if (declaration.type === "TSInterfaceDeclaration") return declaration.body.body;
  if (declaration.typeAnnotation?.type === "TSTypeLiteral") return declaration.typeAnnotation.members;
  return [];
}

function propertyName(member) {
  return member.key?.name ?? staticString(member.key);
}

function propertyTypeNode(member) {
  return member.typeAnnotation?.typeAnnotation;
}

function findForbiddenType(typeNode) {
  let forbidden;

  // Walk the whole TypeScript annotation so nested Array<Map<...>> and function signatures are caught.
  traverse(typeNode, {
    TSTypeReference(child) {
      const name = typeName(child);
      if (forbiddenTypes.has(name)) forbidden = child;
    },
    TSFunctionType(child) {
      forbidden ??= child;
    },
  });

  return forbidden;
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Redux state type includes a non-serializable field.",
  why: "Canonical Redux state must stay JSON-serializable so it can be persisted, replayed, inspected, and compared predictably.",
  fix: "Store plain values such as strings, numbers, booleans, arrays, or records; convert Date/Map/Set/Error/Promise/function values at the boundary.",
  create(_context, { report }) {
    return {
      ExportNamedDeclaration(node) {
        const declaration = node.declaration;
        if (!isStateShape(declaration)) return;

        for (const member of stateMembers(declaration)) {
          const forbidden = findForbiddenType(propertyTypeNode(member));
          if (!forbidden) continue;

          report({
            node: forbidden,
            summary: `Redux state field "${propertyName(member) ?? "unknown"}" uses non-serializable type "${typeName(forbidden)}" in ${declaration.id.name}; store a plain serializable representation instead.`,
          });
        }
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/non-serializable-state-type`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};
export default plugin;
