import { unwrapExpression } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "direct-selector-call-mode";

function selectorReadableCallee(node) {
  if (node?.type !== "CallExpression") return undefined;

  const callee = unwrapExpression(node.callee);
  if (callee?.type !== "Identifier") return undefined;

  return /^select[A-Z]/.test(callee.name) ? callee : undefined;
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Selector readable form was called from an unsafe callback or function context.",
  why: "Bare `selectFoo()` creates a Svelte readable using component context and is only safe during component initialization.",
  fix: "Use `selectFoo.select(store.state, args)` in callbacks/tests or `yield* selectFoo.effect(args)` in sagas; reserve `selectFoo()` for component init.",
  create(_context, { report }) {
    let functionDepth = 0;

    function enterFunction() {
      functionDepth += 1;
    }

    function exitFunction() {
      functionDepth -= 1;
    }

    return {
      FunctionDeclaration: enterFunction,
      "FunctionDeclaration:exit": exitFunction,
      FunctionExpression: enterFunction,
      "FunctionExpression:exit": exitFunction,
      ArrowFunctionExpression: enterFunction,
      "ArrowFunctionExpression:exit": exitFunction,
      CallExpression(node) {
        // Bare readable selectors are only safe while a component initializes.
        // Any nested function/callback may run later and must use an explicit mode.
        if (functionDepth === 0) return;

        const callee = selectorReadableCallee(node);
        if (!callee) return;

        report({
          node: callee,
          summary: "Bare selectFoo() creates a Svelte readable and is only safe at component init; use selectFoo.select(state) in callbacks/handlers or selectFoo.effect() in sagas.",
        });
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/direct-selector-call-mode`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};

export default plugin;
