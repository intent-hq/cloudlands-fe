import { plugin as asyncReducerHandlerPlugin } from "../async-reducer-handler/plugin.mjs";
import { plugin as autoForkingChannelHelperPlugin } from "../auto-forking-channel-helper/plugin.mjs";
import { plugin as collectionInternalMutationPlugin } from "../collection-internal-mutation/plugin.mjs";
import { plugin as collectionStateShapePlugin } from "../collection-state-shape/plugin.mjs";
import { plugin as componentLifecycleBoundaryPlugin } from "../component-lifecycle-boundary/plugin.mjs";
import { plugin as actionTypeShapePlugin } from "../action-type-shape/plugin.mjs";
import { plugin as directLocalStorageUsagePlugin } from "../direct-local-storage-usage/plugin.mjs";
import { plugin as directSelectorCallModePlugin } from "../direct-selector-call-mode/plugin.mjs";
import { plugin as duplicateActionTypePlugin } from "../duplicate-action-type/plugin.mjs";
import { plugin as duplicateSagaNamePlugin } from "../duplicate-saga-name/plugin.mjs";
import { plugin as duplicateSagaRegistrationPlugin } from "../duplicate-saga-registration/plugin.mjs";
import { plugin as duplicateSelectorExportPlugin } from "../duplicate-selector-export/plugin.mjs";
import { plugin as duplicateSelectorImplementationPlugin } from "../duplicate-selector-implementation/plugin.mjs";
import { plugin as duplicateStateFieldPlugin } from "../duplicate-state-field/plugin.mjs";
import { plugin as forbiddenComponentImportPlugin } from "../forbidden-component-import/plugin.mjs";
import { plugin as forbiddenReduxApiPlugin } from "../forbidden-redux-api/plugin.mjs";
import { plugin as inlineSagaSelectorPlugin } from "../inline-saga-selector/plugin.mjs";
import { plugin as nonSerializableInitialStatePlugin } from "../non-serializable-initial-state/plugin.mjs";
import { plugin as nonSerializableStateTypePlugin } from "../non-serializable-state-type/plugin.mjs";
import { plugin as nondeterministicReducerStatePlugin } from "../nondeterministic-reducer-state/plugin.mjs";
import { plugin as passThroughWrapperPlugin } from "../pass-through-wrapper/plugin.mjs";
import { plugin as rawChannelCleanupPlugin } from "../raw-channel-cleanup/plugin.mjs";
import { plugin as reducerSideEffectPlugin } from "../reducer-side-effect/plugin.mjs";
import { plugin as removedMiddlewareSourcePlugin } from "../removed-middleware-source/plugin.mjs";
import { plugin as sagaWatcherActionTypePlugin } from "../saga-watcher-action-type/plugin.mjs";
import { plugin as selectorExportNamePlugin } from "../selector-export-name/plugin.mjs";
import { plugin as selectorFileNamePlugin } from "../selector-file-name/plugin.mjs";
import { plugin as sharedSvelteStoreBoundaryPlugin } from "../shared-svelte-store-boundary/plugin.mjs";
import { plugin as sourceShapedPackageImportPlugin } from "../source-shaped-package-import/plugin.mjs";
import { plugin as stateTypeNamePlugin } from "../state-type-name/plugin.mjs";
import { plugin as storeConstructorSagaMapPlugin } from "../store-constructor-saga-map/plugin.mjs";
import { plugin as suspiciousStateFieldPlugin } from "../suspicious-state-field/plugin.mjs";
import { plugin as testSelectorSelectPlugin } from "../test-selector-select/plugin.mjs";
import { plugin as typedSagaCallMockGuardPlugin } from "../typed-saga-call-mock-guard/plugin.mjs";
import { plugin as typedSagaYieldStarPlugin } from "../typed-saga-yield-star/plugin.mjs";
import { plugin as unnamespacedActionTypePlugin } from "../unnamespaced-action-type/plugin.mjs";
import { plugin as waitForNamedSelectorPlugin } from "../wait-for-named-selector/plugin.mjs";

export {
  actionTypeShapePlugin,
  asyncReducerHandlerPlugin,
  autoForkingChannelHelperPlugin,
  collectionInternalMutationPlugin,
  collectionStateShapePlugin,
  componentLifecycleBoundaryPlugin,
  directLocalStorageUsagePlugin,
  directSelectorCallModePlugin,
  duplicateActionTypePlugin,
  duplicateSagaNamePlugin,
  duplicateSagaRegistrationPlugin,
  duplicateSelectorExportPlugin,
  duplicateSelectorImplementationPlugin,
  duplicateStateFieldPlugin,
  forbiddenComponentImportPlugin,
  forbiddenReduxApiPlugin,
  inlineSagaSelectorPlugin,
  nonSerializableInitialStatePlugin,
  nonSerializableStateTypePlugin,
  nondeterministicReducerStatePlugin,
  passThroughWrapperPlugin,
  rawChannelCleanupPlugin,
  reducerSideEffectPlugin,
  removedMiddlewareSourcePlugin,
  sagaWatcherActionTypePlugin,
  selectorExportNamePlugin,
  selectorFileNamePlugin,
  sharedSvelteStoreBoundaryPlugin,
  sourceShapedPackageImportPlugin,
  stateTypeNamePlugin,
  storeConstructorSagaMapPlugin,
  suspiciousStateFieldPlugin,
  testSelectorSelectPlugin,
  typedSagaCallMockGuardPlugin,
  typedSagaYieldStarPlugin,
  unnamespacedActionTypePlugin,
  waitForNamedSelectorPlugin,
};

export const sourceBoundaryRulePlugins = {
  "forbidden-component-import": forbiddenComponentImportPlugin,
  "component-lifecycle-boundary": componentLifecycleBoundaryPlugin,
  "source-shaped-package-import": sourceShapedPackageImportPlugin,
  "pass-through-wrapper": passThroughWrapperPlugin,
  "selector-file-name": selectorFileNamePlugin,
  "selector-export-name": selectorExportNamePlugin,
  "removed-middleware-source": removedMiddlewareSourcePlugin,
  "shared-svelte-store-boundary": sharedSvelteStoreBoundaryPlugin,
};

export const nativeReplacementRulePlugins = {
  "forbidden-component-import": forbiddenComponentImportPlugin,
  "source-shaped-package-import": sourceShapedPackageImportPlugin,
  "forbidden-redux-api": forbiddenReduxApiPlugin,
  "state-type-name": stateTypeNamePlugin,
  "unnamespaced-action-type": unnamespacedActionTypePlugin,
  "action-type-shape": actionTypeShapePlugin,
  "direct-local-storage-usage": directLocalStorageUsagePlugin,
  "selector-file-name": selectorFileNamePlugin,
  "selector-export-name": selectorExportNamePlugin,
  "removed-middleware-source": removedMiddlewareSourcePlugin,
  "shared-svelte-store-boundary": sharedSvelteStoreBoundaryPlugin,
};

export const aggregateCheckRulePlugins = {
  "duplicate-action-type": duplicateActionTypePlugin,
  "duplicate-selector-export": duplicateSelectorExportPlugin,
  "duplicate-selector-implementation": duplicateSelectorImplementationPlugin,
  "duplicate-saga-name": duplicateSagaNamePlugin,
  "duplicate-saga-registration": duplicateSagaRegistrationPlugin,
  "suspicious-state-field": suspiciousStateFieldPlugin,
  "duplicate-state-field": duplicateStateFieldPlugin,
};

export const stateCollectionReducerRulePlugins = {
  "non-serializable-state-type": nonSerializableStateTypePlugin,
  "non-serializable-initial-state": nonSerializableInitialStatePlugin,
  "nondeterministic-reducer-state": nondeterministicReducerStatePlugin,
  "collection-state-shape": collectionStateShapePlugin,
  "collection-internal-mutation": collectionInternalMutationPlugin,
  "reducer-side-effect": reducerSideEffectPlugin,
  "async-reducer-handler": asyncReducerHandlerPlugin,
};

export const sagaSelectorChannelRulePlugins = {
  "saga-watcher-action-type": sagaWatcherActionTypePlugin,
  "inline-saga-selector": inlineSagaSelectorPlugin,
  "direct-selector-call-mode": directSelectorCallModePlugin,
  "wait-for-named-selector": waitForNamedSelectorPlugin,
  "typed-saga-yield-star": typedSagaYieldStarPlugin,
  "auto-forking-channel-helper": autoForkingChannelHelperPlugin,
  "raw-channel-cleanup": rawChannelCleanupPlugin,
  "store-constructor-saga-map": storeConstructorSagaMapPlugin,
};

export const testPatternRulePlugins = {
  "test-selector-select": testSelectorSelectPlugin,
  "typed-saga-call-mock-guard": typedSagaCallMockGuardPlugin,
};

export const architectureSourceRulePlugins = {
  ...aggregateCheckRulePlugins,
  ...sourceBoundaryRulePlugins,
  ...nativeReplacementRulePlugins,
  ...stateCollectionReducerRulePlugins,
  ...sagaSelectorChannelRulePlugins,
};

export const architectureRulePlugins = {
  ...architectureSourceRulePlugins,
  ...testPatternRulePlugins,
};

export const architectureRules = Object.fromEntries(
  Object.entries(architectureRulePlugins).map(([ruleId, plugin]) => [ruleId, plugin.rules[ruleId]])
);