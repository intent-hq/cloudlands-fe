import { calleeIdentifierName, memberPath, unwrapExpression } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "reducer-side-effect";

const sideEffectCalls = new Set(["fetch", "setTimeout", "setInterval", "queueMicrotask"]);
const nondeterministicMembers = new Set(["Date.now", "Math.random", "crypto.randomUUID"]);

function isReducerFile(path) {
  return /(?:^|\/)[^/]*(?:reducer|slice)\.[cm]?[jt]sx?$/.test(path) || /(?:^|\/)[^/]*-slice\.[cm]?[jt]sx?$/.test(path);
}

function constructorName(node) {
  const callee = unwrapExpression(node?.callee);
  return callee?.type === "Identifier" ? callee.name : undefined;
}

function callName(node) {
  return calleeIdentifierName(node) ?? memberPath(unwrapExpression(node?.callee));
}

function nondeterministicValueLabel(node) {
  if (node?.type === "NewExpression" && constructorName(node) === "Date") return "new Date";
  if (node?.type !== "CallExpression") return undefined;

  const name = callName(node);
  if (nondeterministicMembers.has(name)) return name;
  return calleeIdentifierName(node) === "randomUUID" ? "randomUUID" : undefined;
}

function sideEffectLabel(node) {
  if (node?.type === "NewExpression" && constructorName(node) === "Promise") return "Promise";
  if (node?.type !== "CallExpression" && node?.type !== "MemberExpression") return undefined;

  const name = node.type === "CallExpression" ? callName(node) : memberPath(node);
  if (sideEffectCalls.has(name)) return name === "fetch" ? "fetch" : "timer";
  if (name?.startsWith("window.") || name?.startsWith("document.")) return "DOM/window API";
  if (name?.includes("localStorage")) return "localStorage";
  if (name?.startsWith("Promise.")) return "Promise";
  return nondeterministicValueLabel(node) ?? undefined;
}

function reportReducerSideEffect(report, node) {
  const label = sideEffectLabel(node);
  if (!label) return;

  report({
    node,
    summary: `Reducer/slice file contains side-effect or nondeterministic API "${label}"; reducers must compute next state from state + action only.`,
  });
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Reducer or slice file contains a side effect or nondeterministic API.",
  why: "Reducers must compute next state from only state and action; side effects break replayability and make reducer tests flaky.",
  fix: "Move IO, timers, storage, randomness, and timestamp creation into sagas or action preparation and keep reducers synchronous and pure.",
  create(_context, { classifyPath, report }) {
    return {
      CallExpression(node) {
        if (isReducerFile(classifyPath().path)) reportReducerSideEffect(report, node);
      },
      NewExpression(node) {
        if (isReducerFile(classifyPath().path)) reportReducerSideEffect(report, node);
      },
      MemberExpression(node) {
        // Member expressions catch DOM/window/localStorage reads even when they are not invoked.
        if (isReducerFile(classifyPath().path)) reportReducerSideEffect(report, node);
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/reducer-side-effect`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};
export default plugin;
