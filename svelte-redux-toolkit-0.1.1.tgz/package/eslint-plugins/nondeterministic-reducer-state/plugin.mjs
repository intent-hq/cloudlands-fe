import { calleeIdentifierName, memberPath, memberPropertyName, traverse, unwrapExpression } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "nondeterministic-reducer-state";

const nondeterministicMembers = new Set(["Date.now", "Math.random", "crypto.randomUUID"]);

function isInitialStateIdentifier(node) {
  return node?.type === "Identifier" && (node.name === "initialState" || /initialState$/i.test(node.name));
}

function isReducerFile(path) {
  return /(?:^|\/)[^/]*(?:reducer|slice)\.[cm]?[jt]sx?$/.test(path) || /(?:^|\/)[^/]*-slice\.[cm]?[jt]sx?$/.test(path);
}

function plainObjectInitializer(node) {
  const init = unwrapExpression(node);
  return init?.type === "ObjectExpression" ? init : undefined;
}

function constructorName(node) {
  const callee = unwrapExpression(node?.callee);
  return callee?.type === "Identifier" ? callee.name : undefined;
}

function callName(node) {
  return calleeIdentifierName(node) ?? memberPath(unwrapExpression(node?.callee));
}

function isCreateReducerCall(node) {
  return unwrapExpression(node)?.type === "CallExpression" && calleeIdentifierName(node) === "createReducer";
}

function isCreateReducerBuilderExpression(node) {
  const current = unwrapExpression(node);
  if (isCreateReducerCall(current)) return true;
  if (current?.type !== "CallExpression") return false;

  const callee = unwrapExpression(current.callee);
  return callee?.type === "MemberExpression" && memberPropertyName(callee) === "with" && isCreateReducerBuilderExpression(callee.object);
}

function reducerHandlerArgument(node) {
  const callee = unwrapExpression(node?.callee);
  if (callee?.type !== "MemberExpression" || memberPropertyName(callee) !== "with") return undefined;
  if (!isCreateReducerBuilderExpression(callee.object)) return undefined;
  return unwrapExpression(node.arguments[1]);
}

function unwrapExportedDeclaration(node) {
  return node?.type === "ExportNamedDeclaration" ? node.declaration : node;
}

function recordHandler(handlerFunctions, name, handler) {
  if (!name || !handler?.body) return;
  handlerFunctions.set(name, handlerFunctions.has(name) ? undefined : handler);
}

function collectTopLevelHandlerFunctions(program) {
  const handlerFunctions = new Map();
  for (const statement of program?.body ?? []) {
    const declaration = unwrapExportedDeclaration(statement);
    if (declaration?.type === "FunctionDeclaration") {
      recordHandler(handlerFunctions, declaration.id?.name, declaration);
    } else if (declaration?.type === "VariableDeclaration") {
      for (const declarator of declaration.declarations ?? []) {
        const init = unwrapExpression(declarator.init);
        if (["ArrowFunctionExpression", "FunctionExpression"].includes(init?.type)) recordHandler(handlerFunctions, declarator.id?.name, init);
      }
    }
  }
  return handlerFunctions;
}

function resolveReducerHandler(handler, handlerFunctions) {
  if (["ArrowFunctionExpression", "FunctionExpression"].includes(handler?.type)) return handler;
  if (handler?.type !== "Identifier") return undefined;
  return handlerFunctions.get(handler.name);
}

function nondeterministicValueLabel(node) {
  if (node?.type === "NewExpression" && constructorName(node) === "Date") return "new Date";
  if (node?.type !== "CallExpression") return undefined;

  const name = callName(node);
  if (nondeterministicMembers.has(name)) return name;
  return calleeIdentifierName(node) === "randomUUID" ? "randomUUID" : undefined;
}

function reportInitialStateNondeterminism(report, declarator, objectNode) {
  // Initial state object literals need a deep walk so nested timestamps and UUIDs cannot hide in child values.
  traverse(objectNode, {
    "*"(child) {
      const label = nondeterministicValueLabel(child);
      if (!label) return;

      report({
        node: child,
        summary: `initialState "${declarator.id.name}" uses nondeterministic value "${label}"; derive timestamps/ids outside reducer state initialization.`,
      });
    },
  });
}

function reportReducerNondeterminism(report, node) {
  const label = nondeterministicValueLabel(node);
  if (!label) return;

  report({
    node,
    summary: `Reducer/slice state uses nondeterministic value "${label}"; create timestamps/random IDs in action preparation or saga code, not reducers.`,
  });
}

function reportHandlerNondeterminism(report, handler) {
  if (!handler?.body) return;

  traverse(handler.body, {
    CallExpression(node) {
      reportReducerNondeterminism(report, node);
    },
    NewExpression(node) {
      reportReducerNondeterminism(report, node);
    },
  });
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Reducer or initialState uses nondeterministic data.",
  why: "Reducers must be repeatable for the same state and action so tests, replay, and debugging remain deterministic.",
  fix: "Create timestamps, random IDs, and UUIDs in action preparation or saga code, then pass the produced value through the action payload.",
  create(_context, { classifyPath, report }) {
    let handlerFunctions = new Map();

    return {
      Program(node) {
        handlerFunctions = collectTopLevelHandlerFunctions(node);
      },
      VariableDeclarator(node) {
        if (!isInitialStateIdentifier(node.id)) return;

        const objectNode = plainObjectInitializer(node.init);
        if (objectNode) reportInitialStateNondeterminism(report, node, objectNode);
      },
      CallExpression(node) {
        if (!isReducerFile(classifyPath().path)) return;

        const handler = resolveReducerHandler(reducerHandlerArgument(node), handlerFunctions);
        reportHandlerNondeterminism(report, handler);
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/nondeterministic-reducer-state`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};
export default plugin;
