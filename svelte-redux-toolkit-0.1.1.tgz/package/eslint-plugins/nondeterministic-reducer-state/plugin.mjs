import { calleeIdentifierName, memberPath, traverse, unwrapExpression } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "nondeterministic-reducer-state";

const nondeterministicMembers = new Set(["Date.now", "Math.random", "crypto.randomUUID"]);

function isInitialStateIdentifier(node) {
  return node?.type === "Identifier" && (node.name === "initialState" || /initialState$/i.test(node.name));
}

function isReducerFile(path) {
  return /(?:^|\/)[^/]*(?:reducer|slice)\.[cm]?[jt]sx?$/.test(path) || /(?:^|\/)[^/]*-slice\.[cm]?[jt]sx?$/.test(path);
}

function plainObjectInitializer(node) {
  const init = unwrapExpression(node);
  return init?.type === "ObjectExpression" ? init : undefined;
}

function constructorName(node) {
  const callee = unwrapExpression(node?.callee);
  return callee?.type === "Identifier" ? callee.name : undefined;
}

function callName(node) {
  return calleeIdentifierName(node) ?? memberPath(unwrapExpression(node?.callee));
}

function nondeterministicValueLabel(node) {
  if (node?.type === "NewExpression" && constructorName(node) === "Date") return "new Date";
  if (node?.type !== "CallExpression") return undefined;

  const name = callName(node);
  if (nondeterministicMembers.has(name)) return name;
  return calleeIdentifierName(node) === "randomUUID" ? "randomUUID" : undefined;
}

function reportInitialStateNondeterminism(report, declarator, objectNode) {
  // Initial state object literals need a deep walk so nested timestamps and UUIDs cannot hide in child values.
  traverse(objectNode, {
    "*"(child) {
      const label = nondeterministicValueLabel(child);
      if (!label) return;

      report({
        node: child,
        summary: `initialState "${declarator.id.name}" uses nondeterministic value "${label}"; derive timestamps/ids outside reducer state initialization.`,
      });
    },
  });
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Reducer or initialState uses nondeterministic data.",
  why: "Reducers must be repeatable for the same state and action so tests, replay, and debugging remain deterministic.",
  fix: "Create timestamps, random IDs, and UUIDs in action preparation or saga code, then pass the produced value through the action payload.",
  create(_context, { classifyPath, report }) {
    return {
      VariableDeclarator(node) {
        if (!isInitialStateIdentifier(node.id)) return;

        const objectNode = plainObjectInitializer(node.init);
        if (objectNode) reportInitialStateNondeterminism(report, node, objectNode);
      },
      CallExpression(node) {
        if (!isReducerFile(classifyPath().path)) return;

        const label = nondeterministicValueLabel(node);
        if (label) {
          report({
            node,
            summary: `Reducer/slice state uses nondeterministic value "${label}"; create timestamps/random IDs in action preparation or saga code, not reducers.`,
          });
        }
      },
      NewExpression(node) {
        if (!isReducerFile(classifyPath().path)) return;

        const label = nondeterministicValueLabel(node);
        if (label) {
          report({
            node,
            summary: `Reducer/slice state uses nondeterministic value "${label}"; create timestamps/random IDs in action preparation or saga code, not reducers.`,
          });
        }
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/nondeterministic-reducer-state`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};
export default plugin;
