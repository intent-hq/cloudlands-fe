# svelte-redux-toolkit

![Svelte Redux Toolkit logo](./svt.png)

> Predictable Redux + Saga state management for Svelte 5 apps.

`svelte-redux-toolkit` helps Svelte teams move shared state, async workflows, and derived data out of components and into explicit, testable building blocks. It is a custom Svelte + Redux + Saga package; it is not the official Redux Toolkit and does not use RTK APIs such as `createSlice`, `configureStore`, or `createAsyncThunk`.

## What problems does it solve?

Svelte is great for local UI state. As an app grows, teams often need a more structured home for data that is shared across routes, loaded asynchronously, reused by services, or updated by long-running workflows.

Use this package when you want to:

- Keep shared application state in one predictable Redux store.
- Put API calls, subscriptions, timers, persistence, and other side effects in sagas instead of components.
- Read derived state through selectors that work in Svelte components, event handlers, services, and sagas.
- Avoid unnecessary selector work with proxy-based tracking: selectors record the exact state paths they read, so unrelated state changes can skip needless recomputation and renders.
- Keep UI-facing selector updates smooth under heavy store activity: readable selectors schedule and coalesce updates near frame rate, so a store changing every 1ms does not have to force a render every 1ms.
- Model entity-heavy state with normalized collection helpers.
- Use documented debugging patterns for serializability-focused state modeling and dispatch/store access outside component code.
- Give humans and AI agents the same documented patterns for setup, migration, testing, and review.

## Installation

Install the package and its required peer dependencies in a Svelte 5 project:

```bash
npm install svelte-redux-toolkit redux redux-saga typed-redux-saga fast-equals
```

`svelte@^5` is also a peer dependency and is expected to come from your Svelte app or framework setup.

For saga tests, the docs use `redux-saga-test-plan` as an optional dev dependency:

```bash
npm install -D redux-saga-test-plan
```

### Install side effects

The published package runs a safe `postinstall` script when npm installs it under `node_modules`. That script copies packaged AI skills from this package into the consuming project root at `.agents/skills/`. Before copying, it removes stale package-owned skill files from previous package versions, preserves unrelated project or third-party skills, and excludes generated package artifacts such as `skills/_artifacts`.

### Package CLI

After installation, consuming apps can run the package binary from the app root. The most direct installed-bin check is `./node_modules/.bin/svelte-redux-toolkit help`; it should print help immediately. Standard npm package invocation forms are also supported when npm can resolve the installed local bin. Running the binary with no command, or with `help`, prints the supported commands.

```bash
./node_modules/.bin/svelte-redux-toolkit help
npm exec -- svelte-redux-toolkit help
npx svelte-redux-toolkit
npx svelte-redux-toolkit help
npx svelte-redux-toolkit install-skills
npx svelte-redux-toolkit cleanup-skills
npx svelte-redux-toolkit validate-architecture
npx svelte-redux-toolkit validate-skill-examples
```

Use `install-skills` to copy or refresh the packaged AI skills in `.agents/skills/` from a consuming app when postinstall was skipped or needs refreshing. It removes stale package-owned files before copying current packaged skills and leaves unrelated skills alone. Use `cleanup-skills` to remove package-owned `.agents/skills/` copies before uninstalling. Both maintenance commands print copied, updated, skipped, removed, or no-op output so they should not appear silent. Use `validate-architecture` from an app root to run the packaged architecture validator against that app; use `validate-skill-examples` when validating app-local Markdown skill/doc examples.

If npm package invocation appears to do nothing, verify `./node_modules/.bin/svelte-redux-toolkit` exists in the consuming app and run `./node_modules/.bin/svelte-redux-toolkit help` directly. If that file is missing, the package is not installed or the package manager has not linked its bin in that app; reinstall or repair the local package install before retrying. In this repository's source checkout, `npx`/`npm exec` package-name invocations are not a valid smoke test because the package bin is not linked automatically; use `node scripts/cli.mjs help` for source-checkout validation.

## Uninstall and skill cleanup

npm 7+ does not run dependency uninstall lifecycle scripts, so `npm uninstall svelte-redux-toolkit` will not automatically remove copied skill files. Run cleanup first, then uninstall packages you no longer use:

```bash
npm uninstall svelte-redux-toolkit
npm uninstall redux redux-saga typed-redux-saga fast-equals # only if your app no longer uses them
```

Run the packaged cleanup command before uninstalling. It removes only package-owned copies in `.agents/skills/` and leaves unrelated `.agents/skills` content alone. If you installed the optional saga test dependency only for this package, remove it separately:

```bash
npx svelte-redux-toolkit cleanup-skills
# or: npm exec -- svelte-redux-toolkit cleanup-skills
```

Then remove optional test dependencies if your app does not use them elsewhere:

```bash
npm uninstall -D redux-saga-test-plan
```

If the package has already been uninstalled and the cleanup script is no longer available, remove only copied package-owned skill folders you no longer need, such as `.agents/skills/svelte-redux-toolkit`, `.agents/skills/init-svelte-redux-toolkit`, `.agents/skills/redux-saga`, and `.agents/skills/migrate-to-svelte-redux-toolkit`. Do not delete `.agents/skills` wholesale if it contains skills from other packages or your project.

## Quick start

Pass app-owned reducer maps to the `Store` constructor, register app sagas with `store.registerSagas(...)` before initialization, initialize that instance once from your root Svelte component, and start each saga explicitly by registered name.

### Public import paths

Use the public subpackage entrypoints in application code. Utility modules that are intentionally public also have explicit leaf subpaths; there is no package root or `svelte-redux-toolkit/utils` barrel.

| Subpackage | Use for |
| --- | --- |
| `svelte-redux-toolkit/store` | `Store` only. Use the configured `Store` instance for per-store operations such as init, dispatch, state reads, selectors, and saga startup. Utility helpers are not exported here; use the explicit utility leaf subpaths below. |
| `svelte-redux-toolkit/saga` | Saga authoring helpers, selector-channel effects, retry/timeout utilities, and streaming helpers. |
| `svelte-redux-toolkit/types` | Public TypeScript types |
| `svelte-redux-toolkit/utils/collections/collection-utils` | Direct collection utility access when a package-level leaf import is needed. |
| `svelte-redux-toolkit/utils/store/create-action`, `/create-reducer`, `/boolean-preference`, `/domain-scoped` | The only package-level store utility leaf imports. |
| `svelte-redux-toolkit/utils/sagas/<leaf>` | Approved saga utility leaves: `debounce-saga`, `retry-with-timeout`, `wrap-async-generator`, and `selector-channel-effects`. Safe localStorage helpers are example/app-local utilities, not package exports. |

Migration note: replace old flat package-root imports, removed utilities-subpackage imports, and source-shaped deep imports with one of the public subpackages or approved utility leaf subpaths above. The package does not publish a root runtime API or `utils` directory barrel; choose the explicit subpath that owns the API.

```svelte
<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { Store } from 'svelte-redux-toolkit/store';
  import { counterReducer } from './slices/counter/counter-slice';
  import { counterSaga } from './slices/counter/sagas/counter-saga';

  const store = new Store({ counter: counterReducer });
  store.registerSagas({ counterSaga });

  const dispose = store.init();
  onDestroy(dispose);

  onMount(() => store.runSaga('counterSaga'));
</script>
```

Package-owned internals are managed automatically under reserved `@internal_` names. Internal reducers such as `@internal_storeUtility` are package-managed. The internal saga manager starts during `Store` initialization and is not added to the Store saga registry; `getSagas()` and `getSagaNames()` return only app-owned sagas you register. Do not register `@internal_` reducers or sagas yourself, and do not read those internal state domains directly from app code.

When you need the app state type, infer it from the configured `Store` instance:

```ts
import { Store } from 'svelte-redux-toolkit/store';
import type { StoreInstanceState, StoreSagaName } from 'svelte-redux-toolkit/types';
import { counterReducer } from './slices/counter/counter-slice';
import { counterSaga } from './slices/counter/sagas/counter-saga';

const storeWithReducers = new Store({ counter: counterReducer });
export const store = storeWithReducers.registerSagas({ counterSaga });
export type AppState = StoreInstanceState<typeof store>;
export type AppSagaName = StoreSagaName<typeof store>;
```

The constructor reducer map drives `StoreInstanceState<typeof store>` inference, and the `registerSagas(...)` return value drives `StoreSagaName<typeof store>` inference when you need precise saga-name types. Normal setup does not require an explicit `: Store` annotation. `StoreState<typeof store>` remains supported for state typing. The inferred state type includes package-owned `@internal_` domains for completeness; treat those as implementation details and read app-owned slices through selectors.

Call `store.init(initialState?)` during root component initialization and register the returned disposer with Svelte `onDestroy`. The returned disposer delegates to `store.dispose()`, so `onDestroy(dispose)` remains the preferred root-layout pattern; direct `store.dispose()` is available when non-component code or tests own the whole Store lifetime. Store disposal tears down the initialized context and stops saga tasks owned by that context. Initialization prepares the Redux store and starts the internal saga manager, but it does **not** auto-start registered app sagas.

Start sagas by registered name through the configured `Store` instance. In Svelte components/layouts, call `store.runSaga(name)` from `onMount` so the returned cancel function becomes the mount cleanup; in non-component code, keep and call that cancel function yourself:

```ts
const cancelCounterSaga = store.runSaga('counterSaga');
cancelCounterSaga();
```

## Why it feels good in Svelte

- **Selectors feel native to Svelte.** By default they return Svelte readables, so components can subscribe naturally while `.select(state, ...args)` serves non-component code and `.effect(...args)` serves sagas.
- **Readable updates stay smooth.** Selector readable emissions are capped and coalesced to around frame rate (about 64fps), keeping fast Redux updates from turning into noisy UI work.
- **Cached values stay precise.** Selector caching uses proxy tracking for exactly the state paths read, so unrelated store changes do not have to invalidate derived values.
- **That combination is the fit.** Default readables, frame-friendly emissions, and path-aware caching are the main reason the toolkit works especially well in Svelte.
- **Components stay focused on UI.** Shared state transitions live in reducers, and async work lives in sagas.
- **Workflows are explicit.** Sagas are registered with `store.registerSagas(sagasMap)` before initialization, started through `store.runSaga(name)`, and stopped by the returned cancel function or by full Store teardown through `store.dispose()`.
- **State stays easy to inspect.** Redux state, explicit action flow, and console inspection tools make behavior easier to trace than ad hoc component side effects.

## Learn more

The package includes focused reference docs and agent skills for deeper workflows:

Ownership convention: `docs/` is the human-facing source of truth for concepts,
API summaries, tradeoffs, and examples. `skills/` is concise agent-facing
execution guidance: routing, must-follow rules, pitfalls, verification cues, and
links back to the relevant docs or source instead of duplicating long
explanations. When they diverge, update the docs/source first and keep the skill
as a short operational pointer.

- `docs/ARCHITECTURE.md` — store setup, data flow, selector tracking, and saga lifecycle.
- `docs/INSTALLATION.md` — install side effects, npm 7+ cleanup/uninstall behavior, and maintainer validation.
- `docs/SELECTORS.md` — selector creation, memoization, component reads, non-component reads, and saga usage.
- `docs/SAGAS.md` — typed saga patterns for async workflows.
- `docs/COLLECTIONS.md` — normalized entity state helpers.
- `docs/TESTING.md` — reducer, selector, and saga testing strategies.
- `skills/svelte-redux-toolkit/` — repeatable agent execution guidance.
- `skills/init-svelte-redux-toolkit/` — greenfield setup workflow.
- `skills/migrate-to-svelte-redux-toolkit/` — migration workflow for existing Svelte state.

## Maintainer validation

For this repository, use `npm ci` from a clean checkout to reproduce the committed dependency baseline. Do not use consumer install or uninstall commands for maintainer validation. After dependencies are installed, run:

```bash
npm run validate:architecture
npm run validate:skill-examples
npm test
npm run build
npm run validate:release
git diff --check
git diff --cached --check # when staged changes exist
git status --short
```

Run `npm run validate:architecture` whenever a change touches Redux state,
actions, selectors, sagas, component/store imports, localStorage persistence, or
their skills/docs. Run `npm run validate:skill-examples` when changing skills,
README, or docs code examples so Markdown fences do not teach forbidden
patterns. Passing means the architecture command exits 0 and prints
`[architecture-validation] no architecture gate violations found`. The modular
gate set checks duplicate/canonical owners plus import boundaries, namespaced
action types, serializable Redux state, safe localStorage helper usage, saga
watcher typing, named saga selector usage, RTK/shared Svelte-store boundaries,
collection state shape and internal mutations, runtime state serialization,
reducer purity, conservative component lifecycle/store access, pass-through
wrapper cleanup, selector call modes, typed-redux-saga `yield*` style, channel
lifecycle cleanup, file-structure naming, and high-signal test-pattern hygiene.
Noisy semantic adequacy checks remain verifier-guided rather than brittle CI.
`npm run validate:release` runs the architecture gate first, then builds, checks
`npm pack --dry-run --json` contents, and smoke-tests the public
subpackages plus approved utility leaf subpaths while ensuring the root runtime entry,
source-shaped deep imports, internal utility paths, and removed subpackage exports stay unavailable. Known diagnostics that still
exit 0, such as existing `vite-plugin-dts` messages, must be reported as
non-blocking; unrelated `pnpm-lock.yaml` changes stay out of scope unless the
task explicitly approves package-manager work.

## License

MIT