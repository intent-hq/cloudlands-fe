#!/usr/bin/env node

import { lstat, readdir, readFile } from "node:fs/promises";
import { extname, join, relative, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { unnamespacedActionTypeRule, validateActionNamespaceGate } from "./architecture/action-namespace-gate.mjs";
import { autoForkingChannelHelperRule, rawChannelCleanupRule, validateChannelLifecycleGate } from "./architecture/channel-lifecycle-gate.mjs";
import { collectionInternalMutationRule, validateCollectionInternalMutationGate } from "./architecture/collection-internal-mutation-gate.mjs";
import { collectionStateShapeRule, validateCollectionStateGate } from "./architecture/collection-state-gate.mjs";
import { componentLifecycleBoundaryRule, validateComponentLifecycleBoundaryGate } from "./architecture/component-lifecycle-boundary-gate.mjs";
import { forbiddenComponentImportRule, validateImportBoundariesGate } from "./architecture/import-boundaries-gate.mjs";
import { actionTypeShapeRule, selectorExportNameRule, selectorFileNameRule, stateTypeNameRule, validateFileStructureGate } from "./architecture/file-structure-gate.mjs";
import { directLocalStorageRule, validateLocalStorageGate } from "./architecture/local-storage-gate.mjs";
import { passThroughWrapperRule, validatePassThroughWrapperGate } from "./architecture/pass-through-wrapper-gate.mjs";
import { asyncReducerHandlerRule, reducerSideEffectRule, validateReducerPurityGate } from "./architecture/reducer-purity-gate.mjs";
import { forbiddenReduxApiRule, sharedSvelteStoreRule, validateReduxApiBoundaryGate } from "./architecture/redux-api-boundary-gate.mjs";
import { validateSagaEffectStyleGate, typedSagaYieldStarRule } from "./architecture/saga-effect-style-gate.mjs";
import { inlineSagaSelectorRule, validateSagaSelectorUsageGate } from "./architecture/saga-selector-usage-gate.mjs";
import { sagaWatcherActionTypeRule, validateSagaWatcherPatternsGate } from "./architecture/saga-watcher-patterns-gate.mjs";
import { directSelectorCallModeRule, validateSelectorCallModeGate, waitForNamedSelectorRule } from "./architecture/selector-call-mode-gate.mjs";
import { nondeterministicReducerStateRule, nonSerializableInitialStateRule, validateStateRuntimeSerializationGate } from "./architecture/state-runtime-serialization-gate.mjs";
import { nonSerializableStateTypeRule, validateStateSerializationGate } from "./architecture/state-serialization-gate.mjs";
import { testSelectorSelectRule, typedSagaCallMockGuardRule, validateTestPatternsGate } from "./architecture/test-patterns-gate.mjs";

export const architectureRules = {
  duplicateActionType: "duplicate-action-type",
  duplicateSelectorExport: "duplicate-selector-export",
  duplicateSelectorImplementation: "duplicate-selector-implementation",
  duplicateSagaName: "duplicate-saga-name",
  duplicateSagaRegistration: "duplicate-saga-registration",
  suspiciousStateField: "suspicious-state-field",
  duplicateStateField: "duplicate-state-field",
  forbiddenComponentImport: forbiddenComponentImportRule,
  unnamespacedActionType: unnamespacedActionTypeRule,
  nonSerializableStateType: nonSerializableStateTypeRule,
  directLocalStorageUsage: directLocalStorageRule,
  sagaWatcherActionType: sagaWatcherActionTypeRule,
  inlineSagaSelector: inlineSagaSelectorRule,
  forbiddenReduxApi: forbiddenReduxApiRule,
  sharedSvelteStoreBoundary: sharedSvelteStoreRule,
  collectionStateShape: collectionStateShapeRule,
  collectionInternalMutation: collectionInternalMutationRule,
  nonSerializableInitialState: nonSerializableInitialStateRule,
  nondeterministicReducerState: nondeterministicReducerStateRule,
  reducerSideEffect: reducerSideEffectRule,
  asyncReducerHandler: asyncReducerHandlerRule,
  componentLifecycleBoundary: componentLifecycleBoundaryRule,
  passThroughWrapper: passThroughWrapperRule,
  directSelectorCallMode: directSelectorCallModeRule,
  waitForNamedSelector: waitForNamedSelectorRule,
  typedSagaYieldStar: typedSagaYieldStarRule,
  autoForkingChannelHelper: autoForkingChannelHelperRule,
  rawChannelCleanup: rawChannelCleanupRule,
  stateTypeName: stateTypeNameRule,
  selectorExportName: selectorExportNameRule,
  selectorFileName: selectorFileNameRule,
  actionTypeShape: actionTypeShapeRule,
  testSelectorSelect: testSelectorSelectRule,
  typedSagaCallMockGuard: typedSagaCallMockGuardRule,
};

const modularGates = [
  validateImportBoundariesGate,
  validateActionNamespaceGate,
  validateStateSerializationGate,
  validateLocalStorageGate,
  validateSagaWatcherPatternsGate,
  validateSagaSelectorUsageGate,
  validateReduxApiBoundaryGate,
  validateCollectionStateGate,
  validateCollectionInternalMutationGate,
  validateStateRuntimeSerializationGate,
  validateReducerPurityGate,
  validateComponentLifecycleBoundaryGate,
  validatePassThroughWrapperGate,
  validateSelectorCallModeGate,
  validateSagaEffectStyleGate,
  validateChannelLifecycleGate,
  validateFileStructureGate,
];

const testPatternGates = [validateTestPatternsGate];

const defaultPaths = ["src"];
const sourceExtensions = new Set([".js", ".jsx", ".mjs", ".svelte", ".ts", ".tsx"]);
const ignoredDirectories = new Set([".git", "coverage", "dist", "node_modules"]);
const testFilePattern = /(^|[\\/])[^\\/]+\.(test|spec)\.[^\\/]+$/;
const selectorFactories = new Set(["createSelector", "createCollectionItemSelector", "createCollectionItemsListSelector"]);
const actionFactories = new Set(["createAction", "createAsyncAction"]);

function locationFor(source, index) {
  const before = source.slice(0, index);
  const lines = before.split(/\r?\n/);
  return { line: lines.length, column: lines[lines.length - 1].length + 1 };
}

function normalizePath(path) {
  return path.replace(/\\/g, "/");
}

function isIdentifier(char) {
  return Boolean(char && /[A-Za-z0-9_$]/.test(char));
}

function skipQuoted(source, index) {
  const quote = source[index];
  let cursor = index + 1;
  while (cursor < source.length) {
    if (source[cursor] === "\\") {
      cursor += 2;
      continue;
    }
    if (source[cursor] === quote) return cursor + 1;
    cursor += 1;
  }
  return source.length;
}

function skipTrivia(source, index) {
  let cursor = index;
  while (cursor < source.length) {
    if (/\s/.test(source[cursor])) {
      cursor += 1;
      continue;
    }
    if (source[cursor] === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (source[cursor] === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    return cursor;
  }
  return cursor;
}

function skipTypeArguments(source, index) {
  if (source[index] !== "<") return index;
  let depth = 0;
  let cursor = index;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "<") depth += 1;
    if (char === ">") {
      depth -= 1;
      if (depth === 0) return cursor + 1;
    }
    cursor += 1;
  }
  return index;
}

function readBalanced(source, openIndex, openChar, closeChar) {
  let depth = 0;
  let cursor = openIndex;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (char === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    if (char === openChar) depth += 1;
    if (char === closeChar) {
      depth -= 1;
      if (depth === 0) {
        return { body: source.slice(openIndex + 1, cursor), end: cursor + 1 };
      }
    }
    cursor += 1;
  }
  return undefined;
}

function findCalls(source, names) {
  const calls = [];
  const nameSet = new Set(names);
  const pattern = /[A-Za-z_$][\w$]*/g;
  let match;
  while ((match = pattern.exec(source))) {
    const name = match[0];
    if (!nameSet.has(name) || isIdentifier(source[match.index - 1])) continue;
    let cursor = skipTrivia(source, match.index + name.length);
    if (source[cursor] === "<") cursor = skipTrivia(source, skipTypeArguments(source, cursor));
    if (source[cursor] !== "(") continue;
    const call = readBalanced(source, cursor, "(", ")");
    if (call) calls.push({ name, start: match.index, args: call.body, argsStart: cursor + 1, end: call.end });
  }
  return calls;
}

function splitTopLevelArguments(source) {
  const args = [];
  let start = 0;
  let depth = 0;
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (char === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    if ("({[".includes(char)) depth += 1;
    if (")}]".includes(char)) depth -= 1;
    if (char === "," && depth === 0) {
      args.push({ text: source.slice(start, cursor), offset: start });
      start = cursor + 1;
    }
    cursor += 1;
  }
  args.push({ text: source.slice(start), offset: start });
  return args;
}

function leadingStringLiteral(argument) {
  const trimmedOffset = argument.text.search(/\S/);
  if (trimmedOffset === -1) return undefined;
  const text = argument.text.slice(trimmedOffset);
  const quote = text[0];
  if (!["'", '"', "`"].includes(quote)) return undefined;
  let value = "";
  for (let cursor = 1; cursor < text.length; cursor += 1) {
    const char = text[cursor];
    if (char === "\\") {
      value += text[cursor + 1] ?? "";
      cursor += 1;
      continue;
    }
    if (char === quote) return { value, offset: argument.offset + trimmedOffset };
    if (quote === "`" && char === "$" && text[cursor + 1] === "{") return undefined;
    value += char;
  }
  return undefined;
}

function inferExportedConstName(source, callStart) {
  const prefix = source.slice(Math.max(0, callStart - 250), callStart);
  const match = prefix.match(/(?:^|[;\n])\s*export\s+const\s+([A-Za-z_$][\w$]*)\s*=\s*$/);
  return match?.[1];
}

function inferConstName(source, callStart) {
  const prefix = source.slice(Math.max(0, callStart - 250), callStart);
  const match = prefix.match(/(?:^|[;\n])\s*(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=\s*$/);
  return match?.[1];
}

function removeComments(source) {
  return source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
}

function normalizeSelectorBody(factory, argument) {
  let body = removeComments(argument).trim();
  body = body.replace(/^\(?\s*([^)=]*)\s*\)?\s*=>\s*\{\s*return\s+([\s\S]*?);?\s*\}$/m, "($1)=>$2");
  body = body.replace(/\s+/g, "").replace(/;$/, "");
  return `${factory}:${body}`;
}

function parseIgnoreRules(line, marker) {
  const index = line.indexOf(marker);
  if (index === -1) return undefined;
  const rest = line.slice(index + marker.length).trim();
  if (!rest || rest.startsWith("--")) return new Set(["all"]);
  const ruleText = rest.split("--")[0].trim().replace(/^[:=]/, "").trim();
  if (!ruleText) return new Set(["all"]);
  return new Set(ruleText.split(/[\s,]+/).filter(Boolean));
}

function createIgnoreChecker(source) {
  const lines = source.split(/\r?\n/);
  const fileRules = new Set();
  for (const line of lines) {
    const rules = parseIgnoreRules(line, "architecture-gate-ignore-file");
    if (rules) for (const rule of rules) fileRules.add(rule);
  }
  return (rule, lineNumber) => {
    if (fileRules.has("all") || fileRules.has(rule)) return true;
    const previous = lines[lineNumber - 2] ?? "";
    const current = lines[lineNumber - 1] ?? "";
    for (const line of [previous, current]) {
      const rules = parseIgnoreRules(line, "architecture-gate-ignore-next-line");
      if (rules?.has("all") || rules?.has(rule)) return true;
    }
    return false;
  };
}

function pushRecord(records, rule, file, source, index, key, label) {
  const location = locationFor(source, index);
  if (records.isIgnored(rule, location.line)) return;
  records[rule].push({ key, file, line: location.line, column: location.column, label });
}

function extractTopLevelProperties(body, startLine) {
  const properties = [];
  let depth = 0;
  const lines = body.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const match = depth === 0 ? line.match(/^\s*([A-Za-z_$][\w$]*|["'][^"']+["'])\??\s*:/) : undefined;
    if (match) {
      properties.push({ name: match[1].replace(/^['"]|['"]$/g, ""), line: startLine + index });
    }
    const cleanLine = removeComments(line).replace(/(['"`])(?:\\.|(?!\1).)*\1/g, "");
    for (const char of cleanLine) {
      if ("({[".includes(char)) depth += 1;
      if (")}]".includes(char)) depth = Math.max(0, depth - 1);
    }
  }
  return properties;
}

function extractTopLevelSagaRegistrations(body, startLine) {
  const registrations = [];
  let depth = 0;
  const lines = body.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const match = depth === 0 ? line.match(/^\s*(["']?)([A-Za-z_$][\w$/-]*)\1\s*:\s*([A-Za-z_$][\w$]*Saga)\b/) : undefined;
    if (match) {
      registrations.push({ name: match[2], saga: match[3], line: startLine + index, column: line.indexOf(match[2]) + 1 });
    }
    const cleanLine = removeComments(line).replace(/(['"`])(?:\\.|(?!\1).)*\1/g, "");
    for (const char of cleanLine) {
      if ("({[".includes(char)) depth += 1;
      if (")}]".includes(char)) depth = Math.max(0, depth - 1);
    }
  }
  return registrations;
}

function suspiciousStateReason(field) {
  if (/^(filtered|sorted|visible|displayed|derived|computed|matching)[A-Z_]/.test(field)) {
    return "looks derived from another collection; keep it in a selector unless it is source data";
  }
  if (/(Filtered|Sorted|Visible|Displayed|Derived|Computed|Matching)[A-Z_]/.test(field)) {
    return "looks derived from another state value; keep it in a selector unless it is source data";
  }
  if (/(Count|Total)$/.test(field) && field !== "count") {
    return "looks like an aggregate that should usually be derived by a selector";
  }
  return undefined;
}

function normalizedStateConcept(field) {
  let concept = field.replace(/^(filtered|sorted|visible|displayed|selected|all)/i, "");
  concept = concept.replace(/(ById|Ids|Map|List|Array|Items|Collection|Count|Total)$/i, "");
  concept = concept.toLowerCase().replace(/s$/, "");
  return concept.length >= 3 ? concept : undefined;
}

function hasDuplicatingStateToken(field) {
  return /^(filtered|sorted|visible|displayed|selected|all)/i.test(field) || /(ById|Ids|Map|List|Array|Items|Count|Total)$/i.test(field);
}

function analyzeStateShape(records, file, source, shapeName, properties) {
  const seenNames = new Map();
  const concepts = new Map();
  for (const property of properties) {
    const reason = suspiciousStateReason(property.name);
    if (reason && !records.isIgnored(architectureRules.suspiciousStateField, property.line)) {
      records.diagnostics.push({
        rule: architectureRules.suspiciousStateField,
        file,
        line: property.line,
        column: 1,
        message: `Suspicious Redux state field "${property.name}" in ${shapeName}: ${reason}.`,
      });
    }
    const existingName = seenNames.get(property.name);
    if (existingName && !records.isIgnored(architectureRules.duplicateStateField, property.line)) {
      records.diagnostics.push({
        rule: architectureRules.duplicateStateField,
        file,
        line: property.line,
        column: 1,
        message: `Duplicate Redux state field "${property.name}" in ${shapeName}.`,
      });
    }
    seenNames.set(property.name, property);

    const concept = normalizedStateConcept(property.name);
    const previous = concept ? concepts.get(concept) : undefined;
    if (previous && (hasDuplicatingStateToken(previous.name) || hasDuplicatingStateToken(property.name))) {
      if (!records.isIgnored(architectureRules.duplicateStateField, property.line)) {
        records.diagnostics.push({
          rule: architectureRules.duplicateStateField,
          file,
          line: property.line,
          column: 1,
          message: `Redux state fields "${previous.name}" and "${property.name}" in ${shapeName} look like duplicated representations; keep one source of truth and derive the other in selectors.`,
        });
      }
    } else if (concept) {
      concepts.set(concept, property);
    }
  }
}

function analyzeSource(file, source) {
  const records = {
    diagnostics: [],
    [architectureRules.duplicateActionType]: [],
    [architectureRules.duplicateSelectorExport]: [],
    [architectureRules.duplicateSelectorImplementation]: [],
    [architectureRules.duplicateSagaName]: [],
    [architectureRules.duplicateSagaRegistration]: [],
    isIgnored: createIgnoreChecker(source),
  };

  for (const call of findCalls(source, actionFactories)) {
    const args = splitTopLevelArguments(call.args);
    const actionTypeArgs = call.name === "createAsyncAction" ? args.slice(0, 2) : args.slice(0, 1);
    for (const argument of actionTypeArgs) {
      const literal = leadingStringLiteral(argument);
      if (!literal) continue;
      const index = call.argsStart + literal.offset;
      pushRecord(records, architectureRules.duplicateActionType, file, source, index, literal.value, inferConstName(source, call.start) ?? call.name);
    }
  }

  for (const call of findCalls(source, selectorFactories)) {
    const selectorName = inferExportedConstName(source, call.start);
    if (!selectorName) continue;
    const args = splitTopLevelArguments(call.args);
    const firstArg = args[0]?.text;
    pushRecord(records, architectureRules.duplicateSelectorExport, file, source, call.start, selectorName, selectorName);
    if (firstArg) {
      pushRecord(
        records,
        architectureRules.duplicateSelectorImplementation,
        file,
        source,
        call.argsStart + args[0].offset,
        normalizeSelectorBody(call.name, firstArg),
        selectorName
      );
    }
  }

  for (const pattern of [/(?:export\s+)?function\s*\*\s*([A-Za-z_$][\w$]*Saga)\s*\(/g, /(?:export\s+)?const\s+([A-Za-z_$][\w$]*Saga)\s*=\s*(?:function\s*)?\*/g]) {
    let match;
    while ((match = pattern.exec(source))) {
      pushRecord(records, architectureRules.duplicateSagaName, file, source, match.index, match[1], match[1]);
    }
  }

  for (const call of findCalls(source, ["addSaga"])) {
    const literal = leadingStringLiteral(splitTopLevelArguments(call.args)[0] ?? { text: "", offset: 0 });
    if (literal) {
      pushRecord(records, architectureRules.duplicateSagaRegistration, file, source, call.argsStart + literal.offset, literal.value, "addSaga registration");
    }
  }

  const sagaRegistryPattern = /(?:const|let|var)\s+(sagas|[A-Za-z_$][\w$]*(?:sagas|sagaRegistry))\s*(?::[^=]+)?=\s*\{/gi;
  let registrationMatch;
  while ((registrationMatch = sagaRegistryPattern.exec(source))) {
    const openIndex = source.indexOf("{", registrationMatch.index);
    const registry = readBalanced(source, openIndex, "{", "}");
    if (!registry) continue;
    for (const entry of extractTopLevelSagaRegistrations(registry.body, locationFor(source, openIndex + 1).line)) {
      if (records.isIgnored(architectureRules.duplicateSagaRegistration, entry.line)) continue;
      records[architectureRules.duplicateSagaRegistration].push({
        key: entry.name,
        file,
        line: entry.line,
        column: entry.column,
        label: `${entry.name}: ${entry.saga}`,
      });
    }
  }

  for (const pattern of [/export\s+type\s+([A-Za-z_$][\w$]*State)\s*=\s*\{/g, /export\s+interface\s+([A-Za-z_$][\w$]*State)\s*\{/g]) {
    let match;
    while ((match = pattern.exec(source))) {
      const openIndex = source.indexOf("{", match.index);
      const shape = readBalanced(source, openIndex, "{", "}");
      if (!shape) continue;
      analyzeStateShape(records, file, source, match[1], extractTopLevelProperties(shape.body, locationFor(source, openIndex + 1).line));
    }
  }

  const initialStatePattern = /const\s+([A-Za-z_$][\w$]*initialState|initialState)\s*(?::[^=]+)?=\s*\{/gi;
  let initialStateMatch;
  while ((initialStateMatch = initialStatePattern.exec(source))) {
    const openIndex = source.indexOf("{", initialStateMatch.index);
    const shape = readBalanced(source, openIndex, "{", "}");
    if (!shape) continue;
    analyzeStateShape(records, file, source, initialStateMatch[1], extractTopLevelProperties(shape.body, locationFor(source, openIndex + 1).line));
  }

  return records;
}

async function collectFiles(root, paths, options = {}) {
  const files = [];
  async function visit(absolutePath) {
    const stat = await lstat(absolutePath);
    if (stat.isDirectory()) {
      if (ignoredDirectories.has(absolutePath.split(/[\\/]/).pop())) return;
      const entries = await readdir(absolutePath);
      await Promise.all(entries.map((entry) => visit(join(absolutePath, entry))));
      return;
    }
    const relativePath = normalizePath(relative(root, absolutePath));
    const isTestFile = testFilePattern.test(relativePath);
    if (!sourceExtensions.has(extname(absolutePath)) || (!options.onlyTests && isTestFile) || (options.onlyTests && !isTestFile)) return;
    files.push(absolutePath);
  }
  for (const path of paths) await visit(resolve(root, path));
  return files.sort();
}

function duplicateDiagnostics(rule, records, noun, guidance) {
  const grouped = new Map();
  for (const record of records) {
    const group = grouped.get(record.key) ?? [];
    group.push(record);
    grouped.set(record.key, group);
  }
  return [...grouped.entries()]
    .filter(([, group]) => group.length > 1)
    .map(([key, group]) => ({
      rule,
      file: group[0].file,
      line: group[0].line,
      column: group[0].column,
      message: `Duplicate ${noun} "${key}" found in ${group.length} places. ${guidance}`,
      locations: group.map(({ file, line, column, label }) => ({ file, line, column, label })),
    }));
}

export async function validateArchitecture(options = {}) {
  const root = resolve(options.root ?? process.cwd());
  const paths = options.paths ?? defaultPaths;
  const files = await collectFiles(root, paths);
  const testFiles = await collectFiles(root, paths, { onlyTests: true });
  const aggregate = {
    files: files.map((file) => normalizePath(relative(root, file))),
    testFiles: testFiles.map((file) => normalizePath(relative(root, file))),
    diagnostics: [],
    [architectureRules.duplicateActionType]: [],
    [architectureRules.duplicateSelectorExport]: [],
    [architectureRules.duplicateSelectorImplementation]: [],
    [architectureRules.duplicateSagaName]: [],
    [architectureRules.duplicateSagaRegistration]: [],
  };

  for (const file of files) {
    const source = await readFile(file, "utf8");
    const relativePath = normalizePath(relative(root, file));
    const records = analyzeSource(relativePath, source);
    aggregate.diagnostics.push(...records.diagnostics);
    for (const gate of modularGates) {
      aggregate.diagnostics.push(...gate({ file: relativePath, source }));
    }
    for (const rule of Object.values(architectureRules)) {
      if (records[rule]) aggregate[rule].push(...records[rule]);
    }
  }

  for (const file of testFiles) {
    const source = await readFile(file, "utf8");
    const relativePath = normalizePath(relative(root, file));
    for (const gate of testPatternGates) {
      aggregate.diagnostics.push(...gate({ file: relativePath, source }));
    }
  }

  aggregate.diagnostics.push(
    ...duplicateDiagnostics(architectureRules.duplicateActionType, aggregate[architectureRules.duplicateActionType], "action type string", "Action types must be globally unique."),
    ...duplicateDiagnostics(architectureRules.duplicateSelectorExport, aggregate[architectureRules.duplicateSelectorExport], "selector export", "Give each selector a unique exported name."),
    ...duplicateDiagnostics(architectureRules.duplicateSelectorImplementation, aggregate[architectureRules.duplicateSelectorImplementation], "selector implementation", "Reuse the existing selector or make the derivation distinct."),
    ...duplicateDiagnostics(architectureRules.duplicateSagaName, aggregate[architectureRules.duplicateSagaName], "saga function name", "Rename one saga or reuse the existing implementation."),
    ...duplicateDiagnostics(architectureRules.duplicateSagaRegistration, aggregate[architectureRules.duplicateSagaRegistration], "saga registration", "Each saga registry key/name must be unique within the validation scope.")
  );

  aggregate.diagnostics.sort((a, b) => a.file.localeCompare(b.file) || a.line - b.line || a.rule.localeCompare(b.rule));
  return aggregate;
}

export function formatDiagnostics(diagnostics) {
  if (diagnostics.length === 0) return "[architecture-validation] no architecture gate violations found";
  return diagnostics
    .map((diagnostic) => {
      const header = `[${diagnostic.rule}] ${diagnostic.file}:${diagnostic.line}:${diagnostic.column} ${diagnostic.message}`;
      const locations = diagnostic.locations?.map((location) => `  - ${location.file}:${location.line}:${location.column} ${location.label}`).join("\n");
      return locations ? `${header}\n${locations}` : header;
    })
    .join("\n\n");
}

function parseCliArgs(argv) {
  const options = { paths: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--root") {
      options.root = argv[++index];
    } else if (arg === "--json") {
      options.json = true;
    } else {
      options.paths.push(arg);
    }
  }
  if (options.paths.length === 0) delete options.paths;
  return options;
}

export async function main(argv = process.argv.slice(2)) {
  const options = parseCliArgs(argv);
  const result = await validateArchitecture(options);
  if (options.json) {
    console.log(JSON.stringify(result, null, 2));
  } else {
    console.log(formatDiagnostics(result.diagnostics));
    const testFileCount = result.testFiles?.length ?? 0;
    const testFileSummary = testFileCount > 0 ? ` and ${testFileCount} test files` : "";
    console.log(`[architecture-validation] scanned ${result.files.length} source files${testFileSummary}`);
  }
  return result.diagnostics.length === 0 ? 0 : 1;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const exitCode = await main();
  process.exit(exitCode);
}