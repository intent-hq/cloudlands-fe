import { createIgnoreChecker, diagnostic, isComponentFile, lineStartIndex } from "./shared.mjs";

export const forbiddenComponentImportRule = "forbidden-component-import";

function forbiddenImportReason(importClause, sourcePath) {
  if (sourcePath === "typed-redux-saga" || sourcePath === "redux-saga" || sourcePath.startsWith("redux-saga/")) {
    return "saga effect libraries are saga-only and must not be imported by components";
  }
  if (/(^|\/)sagas?\//.test(sourcePath) || /-saga(?:\.[cm]?[jt]sx?)?$/.test(sourcePath)) {
    return "components must dispatch actions rather than importing saga source";
  }
  if (sourcePath.includes("collection-utils")) {
    return "components must read collections through selectors, not collection internals";
  }
  if (sourcePath.includes("create-reducer")) {
    return "reducer construction is store internals and must not be imported by components";
  }
  if (sourcePath.includes("redux-dispatch-bridge")) {
    return "redux-dispatch-bridge is removed from current guidance; import the initialized app Store instance and use store.dispatch/store.state instead";
  }
  return undefined;
}

export function validateImportBoundariesGate({ file, source }) {
  if (!isComponentFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const importPattern = /import\s+(?:type\s+)?([\s\S]*?)\s+from\s+["']([^"']+)["']/g;
  let match;
  while ((match = importPattern.exec(source))) {
    const locationLine = source.slice(0, match.index).split(/\r?\n/).length;
    const reason = forbiddenImportReason(match[1], match[2]);
    if (!reason || isIgnored(forbiddenComponentImportRule, locationLine)) continue;
    diagnostics.push(
      diagnostic(
        forbiddenComponentImportRule,
        file,
        source,
        lineStartIndex(source, locationLine) + source.split(/\r?\n/)[locationLine - 1].indexOf(match[2]),
        `Forbidden component import "${match[2]}": ${reason}.`
      )
    );
  }
  return diagnostics;
}