import { createIgnoreChecker, diagnostic, findCalls, locationFor, maskComments, skipQuoted } from "./shared.mjs";

export const testSelectorSelectRule = "test-selector-select";
export const typedSagaCallMockGuardRule = "typed-saga-call-mock-guard";

function linePrefix(source, index) {
  const lineStart = source.lastIndexOf("\n", index - 1) + 1;
  return source.slice(lineStart, index);
}

function isStateLikeArgument(argument) {
  const text = argument.trim();
  return text.startsWith("{") || /^with[A-Za-z0-9_$]*\s*\(/.test(text) || /^[A-Za-z_$][\w$]*$/.test(text) && /state/i.test(text);
}

function selectorCallNames(source) {
  return new Set([...source.matchAll(/\b(select[A-Z][A-Za-z0-9_$]*)\s*(?:<[^>\n]+>\s*)?\(/g)].map((match) => match[1]));
}

function maskTemplateLiterals(source) {
  let masked = "";
  let cursor = 0;
  while (cursor < source.length) {
    if (source[cursor] === "`") {
      const end = skipQuoted(source, cursor);
      masked += source.slice(cursor, end).replace(/[^\r\n]/g, " ");
      cursor = end;
      continue;
    }
    masked += source[cursor];
    cursor += 1;
  }
  return masked;
}

function pushSelectorTestDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  for (const call of findCalls(maskedSource, selectorCallNames(maskedSource))) {
    const prefix = linePrefix(maskedSource, call.start);
    if (/\.\s*$/.test(prefix) || /(?:function\*?|const|let|var|import|type|interface)\s*$/.test(prefix)) continue;
    const firstArg = call.args.split(",")[0] ?? "";
    if (!isStateLikeArgument(firstArg)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(testSelectorSelectRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        testSelectorSelectRule,
        file,
        source,
        call.start,
        "Selector tests must call selectFoo.select(state, ...args); selectFoo(state) invokes the readable form and needs Svelte component context."
      )
    );
  }
}

function pushTypedSagaMockDiagnostics({ diagnostics, file, source, isIgnored }) {
  const scanSource = maskTemplateLiterals(maskComments(source));
  const mockMatch = scanSource.match(/vi\.mock\s*\(\s*["']typed-redux-saga["']/);
  if (!mockMatch) return;
  const callMatch = scanSource.match(/\bcall\s*:\s*(?:function\*?\s*)?\(/);
  if (!callMatch || /\bArray\.isArray\s*\(/.test(scanSource)) return;
  const location = locationFor(source, callMatch.index ?? mockMatch.index ?? 0);
  if (isIgnored(typedSagaCallMockGuardRule, location.line)) return;
  diagnostics.push(
    diagnostic(
      typedSagaCallMockGuardRule,
      file,
      source,
      callMatch.index ?? mockMatch.index ?? 0,
      "typed-redux-saga call mocks must guard Array.isArray(fnOrDescriptor) so [context, method] tuple calls work under redux-saga-test-plan."
    )
  );
}

export function validateTestPatternsGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskTemplateLiterals(maskComments(source));
  pushSelectorTestDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  pushTypedSagaMockDiagnostics({ diagnostics, file, source, isIgnored });
  return diagnostics;
}