import { createIgnoreChecker, diagnostic, findActionTypeLiterals, findCalls, locationFor, maskComments } from "./shared.mjs";

export const stateTypeNameRule = "state-type-name";
export const selectorExportNameRule = "selector-export-name";
export const selectorFileNameRule = "selector-file-name";
export const actionTypeShapeRule = "action-type-shape";

const selectorFactories = new Set(["createSelector", "createCollectionItemSelector", "createCollectionItemsListSelector"]);

function fileName(file) {
  return file.split("/").pop() ?? file;
}

function isSelectorFile(file) {
  return /(?:^|\/)[^/]*selectors?\.[cm]?[jt]sx?$/.test(file);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function inferExportedConstName(source, callStart) {
  const prefix = source.slice(Math.max(0, callStart - 250), callStart);
  return prefix.match(/(?:^|[;\n])\s*export\s+const\s+([A-Za-z_$][\w$]*)\s*=\s*$/)?.[1];
}

function exportedStateShapeMatches(source) {
  return [
    /export\s+type\s+([A-Za-z_$][\w$]*)\s*=\s*\{/g,
    /export\s+interface\s+([A-Za-z_$][\w$]*)\s*\{/g,
  ].flatMap((pattern) => {
    const matches = [];
    let match;
    while ((match = pattern.exec(source))) matches.push(match);
    return matches;
  });
}

function isUsedAsReducerState(source, typeName) {
  const escaped = escapeRegExp(typeName);
  return new RegExp(`\\binitialState\\s*:\\s*${escaped}\\b`).test(source) || new RegExp(`\\bcreateReducer\\s*<\\s*${escaped}\\b`).test(source);
}

function pushStateTypeNameDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  for (const match of exportedStateShapeMatches(maskedSource)) {
    const typeName = match[1];
    if (typeName.endsWith("State") || !isUsedAsReducerState(maskedSource, typeName)) continue;
    const location = locationFor(source, match.index);
    if (isIgnored(stateTypeNameRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        stateTypeNameRule,
        file,
        source,
        match.index,
        `Exported Redux state type "${typeName}" is used by initialState/createReducer and must end with State.`
      )
    );
  }
}

function pushSelectorDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  const selectorCalls = findCalls(maskedSource, selectorFactories);
  for (const call of selectorCalls) {
    const exportName = inferExportedConstName(maskedSource, call.start);
    if (!exportName) continue;
    const location = locationFor(source, call.start);
    if (!exportName.startsWith("select") && isSelectorFile(file) && !isIgnored(selectorExportNameRule, location.line)) {
      diagnostics.push(
        diagnostic(
          selectorExportNameRule,
          file,
          source,
          call.start,
          `Selector export "${exportName}" in ${fileName(file)} must start with select so .select/.effect usage is discoverable.`
        )
      );
    }
    if (exportName.startsWith("select") && !isSelectorFile(file) && !isIgnored(selectorFileNameRule, location.line)) {
      diagnostics.push(
        diagnostic(
          selectorFileNameRule,
          file,
          source,
          call.start,
          `Exported selector "${exportName}" should live in a selectors file such as "${fileName(file).replace(/\.[^.]+$/, "")}-selectors.ts".`
        )
      );
    }
  }
}

function pushActionTypeShapeDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  for (const literal of findActionTypeLiterals(maskedSource)) {
    const segments = literal.value.split("/");
    if (segments.length <= 1 || (segments.length === 2 && segments.every(Boolean))) continue;
    const location = locationFor(source, literal.index);
    if (isIgnored(actionTypeShapeRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        actionTypeShapeRule,
        file,
        source,
        literal.index,
        `Action type "${literal.value}" must use exactly "sliceName/actionName"; avoid empty or nested action namespaces.`
      )
    );
  }
}

export function validateFileStructureGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskComments(source);
  pushStateTypeNameDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  pushSelectorDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  pushActionTypeShapeDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  return diagnostics;
}