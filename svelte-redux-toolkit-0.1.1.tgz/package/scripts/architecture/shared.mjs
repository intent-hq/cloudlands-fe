export function locationFor(source, index) {
  const before = source.slice(0, index);
  const lines = before.split(/\r?\n/);
  return { line: lines.length, column: lines[lines.length - 1].length + 1 };
}

export function lineStartIndex(source, lineNumber) {
  let index = 0;
  for (let line = 1; line < lineNumber; line += 1) {
    const next = source.indexOf("\n", index);
    if (next === -1) return source.length;
    index = next + 1;
  }
  return index;
}

function parseIgnoreRules(line, marker) {
  const index = line.indexOf(marker);
  if (index === -1) return undefined;
  const rest = line.slice(index + marker.length).trim();
  if (!rest || rest.startsWith("--")) return new Set(["all"]);
  const ruleText = rest.split("--")[0].trim().replace(/^[:=]/, "").trim();
  if (!ruleText) return new Set(["all"]);
  return new Set(ruleText.split(/[\s,]+/).filter(Boolean));
}

export function createIgnoreChecker(source) {
  const lines = source.split(/\r?\n/);
  const fileRules = new Set();
  for (const line of lines) {
    const rules = parseIgnoreRules(line, "architecture-gate-ignore-file");
    if (rules) for (const rule of rules) fileRules.add(rule);
  }
  return (rule, lineNumber) => {
    if (fileRules.has("all") || fileRules.has(rule)) return true;
    const previous = lines[lineNumber - 2] ?? "";
    const current = lines[lineNumber - 1] ?? "";
    for (const line of [previous, current]) {
      const rules = parseIgnoreRules(line, "architecture-gate-ignore-next-line");
      if (rules?.has("all") || rules?.has(rule)) return true;
    }
    return false;
  };
}

export function diagnostic(rule, file, source, index, message) {
  const location = locationFor(source, index);
  return { rule, file, line: location.line, column: location.column, message };
}

export function removeComments(source) {
  return source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
}

export function maskComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, (comment) => comment.replace(/[^\r\n]/g, " "))
    .replace(/\/\/.*$/gm, (comment) => comment.replace(/[^\r\n]/g, " "));
}

function isIdentifier(char) {
  return Boolean(char && /[A-Za-z0-9_$]/.test(char));
}

export function skipQuoted(source, index) {
  const quote = source[index];
  let cursor = index + 1;
  while (cursor < source.length) {
    if (source[cursor] === "\\") {
      cursor += 2;
      continue;
    }
    if (source[cursor] === quote) return cursor + 1;
    cursor += 1;
  }
  return source.length;
}

export function skipTrivia(source, index) {
  let cursor = index;
  while (cursor < source.length) {
    if (/\s/.test(source[cursor])) {
      cursor += 1;
      continue;
    }
    if (source[cursor] === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (source[cursor] === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    return cursor;
  }
  return cursor;
}

export function skipTypeArguments(source, index) {
  if (source[index] !== "<") return index;
  let depth = 0;
  let cursor = index;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "<") depth += 1;
    if (char === ">") {
      depth -= 1;
      if (depth === 0) return cursor + 1;
    }
    cursor += 1;
  }
  return index;
}

export function readBalanced(source, openIndex, openChar, closeChar) {
  let depth = 0;
  let cursor = openIndex;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (char === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    if (char === openChar) depth += 1;
    if (char === closeChar) {
      depth -= 1;
      if (depth === 0) return { body: source.slice(openIndex + 1, cursor), end: cursor + 1 };
    }
    cursor += 1;
  }
  return undefined;
}

export function findCalls(source, names) {
  const calls = [];
  const nameSet = new Set(names);
  const pattern = /[A-Za-z_$][\w$]*/g;
  let match;
  while ((match = pattern.exec(source))) {
    const name = match[0];
    if (!nameSet.has(name) || isIdentifier(source[match.index - 1])) continue;
    let cursor = skipTrivia(source, match.index + name.length);
    if (source[cursor] === "<") cursor = skipTrivia(source, skipTypeArguments(source, cursor));
    if (source[cursor] !== "(") continue;
    const call = readBalanced(source, cursor, "(", ")");
    if (call) calls.push({ name, start: match.index, args: call.body, argsStart: cursor + 1, end: call.end });
  }
  return calls;
}

export function splitTopLevelArguments(source) {
  const args = [];
  let start = 0;
  let depth = 0;
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (char === "'" || char === '"' || char === "`") {
      cursor = skipQuoted(source, cursor);
      continue;
    }
    if (char === "/" && source[cursor + 1] === "/") {
      const nextLine = source.indexOf("\n", cursor + 2);
      cursor = nextLine === -1 ? source.length : nextLine + 1;
      continue;
    }
    if (char === "/" && source[cursor + 1] === "*") {
      const end = source.indexOf("*/", cursor + 2);
      cursor = end === -1 ? source.length : end + 2;
      continue;
    }
    if ("({[".includes(char)) depth += 1;
    if (")}]".includes(char)) depth -= 1;
    if (char === "," && depth === 0) {
      args.push({ text: source.slice(start, cursor), offset: start });
      start = cursor + 1;
    }
    cursor += 1;
  }
  args.push({ text: source.slice(start), offset: start });
  return args;
}

export function leadingStringLiteral(argument) {
  const trimmedOffset = argument.text.search(/\S/);
  if (trimmedOffset === -1) return undefined;
  const text = argument.text.slice(trimmedOffset);
  const quote = text[0];
  if (!["'", '"', "`"].includes(quote)) return undefined;
  let value = "";
  for (let cursor = 1; cursor < text.length; cursor += 1) {
    const char = text[cursor];
    if (char === "\\") {
      value += text[cursor + 1] ?? "";
      cursor += 1;
      continue;
    }
    if (char === quote) return { value, offset: argument.offset + trimmedOffset };
    if (quote === "`" && char === "$" && text[cursor + 1] === "{") return undefined;
    value += char;
  }
  return undefined;
}

export function findActionTypeLiterals(source) {
  const literals = [];
  for (const call of findCalls(source, ["createAction", "createAsyncAction"])) {
    const args = splitTopLevelArguments(call.args);
    const actionTypeArgs = call.name === "createAsyncAction" ? args.slice(0, 2) : args.slice(0, 1);
    for (const argument of actionTypeArgs) {
      const literal = leadingStringLiteral(argument);
      if (literal) literals.push({ ...literal, index: call.argsStart + literal.offset, callName: call.name });
    }
  }
  return literals;
}

export function isSagaFile(file) {
  return /(^|\/)sagas?\//.test(file) || /-saga\.[cm]?[jt]sx?$/.test(file);
}

export function isComponentFile(file) {
  return file.endsWith(".svelte");
}