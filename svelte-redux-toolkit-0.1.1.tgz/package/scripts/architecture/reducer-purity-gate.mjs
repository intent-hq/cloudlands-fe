import { createIgnoreChecker, diagnostic, lineStartIndex, maskComments } from "./shared.mjs";

export const reducerSideEffectRule = "reducer-side-effect";
export const asyncReducerHandlerRule = "async-reducer-handler";

const sideEffectPatterns = [
  { label: "fetch", pattern: /\bfetch\s*\(/ },
  { label: "timer", pattern: /\b(?:setTimeout|setInterval|queueMicrotask)\s*\(/ },
  { label: "DOM/window API", pattern: /\b(?:window|document)\s*\./ },
  { label: "localStorage", pattern: /\b(?:window\.)?localStorage\s*\./ },
  { label: "Promise", pattern: /\b(?:new\s+Promise|Promise\.)/ },
  { label: "Date.now", pattern: /\bDate\.now\s*\(/ },
  { label: "new Date", pattern: /\bnew\s+Date\s*\(/ },
  { label: "Math.random", pattern: /\bMath\.random\s*\(/ },
  { label: "randomUUID", pattern: /\b(?:crypto\.)?randomUUID\s*\(/ },
];

function isReducerFile(file) {
  return /(?:^|\/)[^/]*(?:reducer|slice)\.[cm]?[jt]sx?$/.test(file) || /(?:^|\/)[^/]*-slice\.[cm]?[jt]sx?$/.test(file);
}

export function validateReducerPurityGate({ file, source }) {
  if (!isReducerFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const lines = maskComments(source).split(/\r?\n/);

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const lineNumber = index + 1;
    if (/\.with\s*\([\s\S]*,\s*async\b|\basync\s*(?:function)?\s*\(?[^=]*\)?\s*=>/.test(line) && !isIgnored(asyncReducerHandlerRule, lineNumber)) {
      diagnostics.push(
        diagnostic(
          asyncReducerHandlerRule,
          file,
          source,
          lineStartIndex(source, lineNumber) + line.search(/\S/),
          "Reducer handlers must be synchronous and pure; move async work into sagas or action preparation."
        )
      );
    }
    for (const { label, pattern } of sideEffectPatterns) {
      if (!pattern.test(line) || isIgnored(reducerSideEffectRule, lineNumber)) continue;
      diagnostics.push(
        diagnostic(
          reducerSideEffectRule,
          file,
          source,
          lineStartIndex(source, lineNumber) + line.search(/\S/),
          `Reducer/slice file contains side-effect or nondeterministic API "${label}"; reducers must compute next state from state + action only.`
        )
      );
    }
  }

  return diagnostics;
}