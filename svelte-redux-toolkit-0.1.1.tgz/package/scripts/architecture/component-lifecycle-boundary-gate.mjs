import { createIgnoreChecker, diagnostic, findCalls, isComponentFile, lineStartIndex, locationFor, maskComments } from "./shared.mjs";

export const componentLifecycleBoundaryRule = "component-lifecycle-boundary";

const lifecycleCalls = ["onMount", "beforeUpdate", "afterUpdate"];

function usesReduxStoreAccess(text) {
  return /\b(?:getDispatch|getReduxStore)\s*\(/.test(text) || /\b[A-Za-z_$][\w$]*\s*\.\s*(?:dispatch|state)\b/.test(text);
}

function reduxStoreAccessIndex(line) {
  const helperIndex = line.search(/\b(?:getDispatch|getReduxStore)\s*\(/);
  if (helperIndex !== -1) return helperIndex;
  return line.search(/\b[A-Za-z_$][\w$]*\s*\.\s*(?:dispatch|state)\b/);
}

export function validateComponentLifecycleBoundaryGate({ file, source }) {
  if (!isComponentFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskComments(source);

  for (const call of findCalls(maskedSource, lifecycleCalls)) {
    if (!usesReduxStoreAccess(call.args)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(componentLifecycleBoundaryRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        componentLifecycleBoundaryRule,
        file,
        source,
        call.start,
        "Do not acquire Redux dispatch/store inside component lifecycle callbacks; bind dispatch at component setup and keep lifecycle work action-driven."
      )
    );
  }

  const lines = maskedSource.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const lineNumber = index + 1;
    if (!/^\s*\$:\s*/.test(line) && !/\b(?:addEventListener|setTimeout|setInterval)\s*\([\s\S]*(?:\b(?:getDispatch|getReduxStore)\s*\(|\b[A-Za-z_$][\w$]*\s*\.\s*(?:dispatch|state)\b)/.test(line)) continue;
    if (!usesReduxStoreAccess(line) || isIgnored(componentLifecycleBoundaryRule, lineNumber)) continue;
    diagnostics.push(
      diagnostic(
        componentLifecycleBoundaryRule,
        file,
        source,
        lineStartIndex(source, lineNumber) + reduxStoreAccessIndex(line),
        "Redux Store access in reactive or callback code is lifecycle-coupled; dispatch actions from explicit handlers and use selectors for reads."
      )
    );
  }

  return diagnostics;
}