import { createIgnoreChecker, diagnostic, findCalls, lineStartIndex, locationFor, maskComments } from "./shared.mjs";

export const forbiddenReduxApiRule = "forbidden-redux-api";
export const sharedSvelteStoreRule = "shared-svelte-store-boundary";
export const sourceShapedPackageImportRule = "source-shaped-package-import";

const forbiddenRtkHelpers = ["createSlice", "configureStore", "createAsyncThunk", "createEntityAdapter", "createListenerMiddleware"];
const removedPublicHelpers = ["createMiddleware", "createReferenceChangeDetectorMiddleware", "createStoreContext", "createReduxStoreContext"];
const sourceShapedPackageImports = new Set([
  "svelte-redux-toolkit",
  "svelte-redux-toolkit/middleware",
  "svelte-redux-toolkit/init",
  "svelte-redux-toolkit/redux-dispatch-bridge",
  "../slices/store-utility/store-utility-slice",
  "../middleware",
  "../middlewares/default",
  "../middlewares/saga",
  "../middlewares/state-reference-checks",
  "../utils/store/create-action",
  "../utils/store/create-reducer",
  "../utils/store/create-middleware",
]);
const approvedUtilityPackageImports = new Set([
  "svelte-redux-toolkit/utils/collections/collection-utils",
  "svelte-redux-toolkit/utils/store/create-action",
  "svelte-redux-toolkit/utils/store/create-reducer",
  "svelte-redux-toolkit/utils/store/boolean-preference",
  "svelte-redux-toolkit/utils/store/domain-scoped",
  "svelte-redux-toolkit/utils/sagas/debounce-saga",
  "svelte-redux-toolkit/utils/sagas/retry-with-timeout",
  "svelte-redux-toolkit/utils/sagas/wrap-async-generator",
  "svelte-redux-toolkit/utils/sagas/selector-channel-effects",
]);

function isReduxToolkitImport(sourcePath) {
  return sourcePath === "@reduxjs/toolkit" || sourcePath.startsWith("@reduxjs/toolkit/");
}

function isSourceShapedPackageImport(sourcePath) {
  if (sourceShapedPackageImports.has(sourcePath)) return true;
  if (approvedUtilityPackageImports.has(sourcePath)) return false;
  return /^svelte-redux-toolkit\/(?:src|components|slices|middlewares?|utils(?:$|\/)|init(?:$|\/)|redux-dispatch-bridge(?:$|\/))/.test(sourcePath);
}

function isRemovedMiddlewareSourceFile(file) {
  return file === "src/middleware.ts" || /^src\/middlewares\//.test(file);
}

function isAllowedComponentLocalStore(file) {
  return /(^|\/)components?\//.test(file) || /(^|\/)(fixtures?|migrations?|migration)\//.test(file);
}

export function validateReduxApiBoundaryGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskComments(source);

  if (isRemovedMiddlewareSourceFile(file) && !isIgnored(sourceShapedPackageImportRule, 1)) {
    diagnostics.push(
      diagnostic(
        sourceShapedPackageImportRule,
        file,
        source,
        0,
        `Removed middleware source path "${file}" is not allowed; use Store constructor middleware or Store.addMiddleware instead.`
      )
    );
  }

  if (file.endsWith(".store.svelte.ts") && !isAllowedComponentLocalStore(file) && !isIgnored(sharedSvelteStoreRule, 1)) {
    diagnostics.push(
      diagnostic(
        sharedSvelteStoreRule,
        file,
        source,
        0,
        "Shared/domain Svelte store files (*.store.svelte.ts) are deprecated; move shared state to Redux or keep only component-local/migration fixtures."
      )
    );
  }

  const importPattern = /import\s+(?:type\s+)?([\s\S]*?)\s+from\s+["']([^"']+)["']/g;
  let importMatch;
  while ((importMatch = importPattern.exec(maskedSource))) {
    const line = locationFor(source, importMatch.index).line;
    if (isSourceShapedPackageImport(importMatch[2]) && !isIgnored(sourceShapedPackageImportRule, line)) {
      diagnostics.push(
        diagnostic(
          sourceShapedPackageImportRule,
          file,
          source,
          lineStartIndex(source, line) + source.split(/\r?\n/)[line - 1].indexOf(importMatch[2]),
          `Source-shaped package import "${importMatch[2]}" is not allowed; import from an approved svelte-redux-toolkit subpackage instead.`
        )
      );
    }
    if (!isReduxToolkitImport(importMatch[2])) continue;
    if (isIgnored(forbiddenReduxApiRule, line)) continue;
    const importedHelpers = forbiddenRtkHelpers.filter((helper) => new RegExp(`\\b${helper}\\b`).test(importMatch[1]));
    const label = importedHelpers.length > 0 ? `RTK helper(s) ${importedHelpers.join(", ")}` : `Redux Toolkit import "${importMatch[2]}"`;
    diagnostics.push(
      diagnostic(
        forbiddenReduxApiRule,
        file,
        source,
        lineStartIndex(source, line) + source.split(/\r?\n/)[line - 1].indexOf(importMatch[2]),
        `${label} is not allowed; use this package's custom Redux utilities instead of @reduxjs/toolkit APIs.`
      )
    );
  }

  for (const call of findCalls(maskedSource, forbiddenRtkHelpers)) {
    const location = locationFor(source, call.start);
    if (isIgnored(forbiddenReduxApiRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        forbiddenReduxApiRule,
        file,
        source,
        call.start,
        `Forbidden RTK-style helper "${call.name}" found; use createAction/createAsyncAction/createReducer from svelte-redux-toolkit instead.`
      )
    );
  }

  for (const call of findCalls(maskedSource, removedPublicHelpers)) {
    const location = locationFor(source, call.start);
    if (isIgnored(forbiddenReduxApiRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        forbiddenReduxApiRule,
        file,
        source,
        call.start,
        `Removed public helper "${call.name}" found; use the current Store-first public API instead.`
      )
    );
  }

  const debugStateRefsIndex = maskedSource.indexOf("debug-state-refs");
  if (debugStateRefsIndex !== -1) {
    const location = locationFor(source, debugStateRefsIndex);
    if (!isIgnored(forbiddenReduxApiRule, location.line)) {
      diagnostics.push(
        diagnostic(
          forbiddenReduxApiRule,
          file,
          source,
          debugStateRefsIndex,
          `Removed debug-state-refs middleware flag found; do not reintroduce the removed reference-change detector middleware.`
        )
      );
    }
  }

  return diagnostics;
}