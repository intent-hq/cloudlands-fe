import { createIgnoreChecker, diagnostic, findCalls, isComponentFile, isSagaFile, locationFor, maskComments, skipQuoted, splitTopLevelArguments } from "./shared.mjs";

export const directSelectorCallModeRule = "direct-selector-call-mode";
export const waitForNamedSelectorRule = "wait-for-named-selector";

function maskStringLiterals(source) {
  let masked = "";
  let cursor = 0;
  while (cursor < source.length) {
    if (["'", '"', "`"].includes(source[cursor])) {
      const end = skipQuoted(source, cursor);
      masked += source.slice(cursor, end).replace(/[^\r\n]/g, " ");
      cursor = end;
      continue;
    }
    masked += source[cursor];
    cursor += 1;
  }
  return masked;
}

function scriptRanges(source) {
  const ranges = [];
  const pattern = /<script\b[^>]*>/gi;
  let match;
  while ((match = pattern.exec(source))) {
    const close = source.indexOf("</script>", pattern.lastIndex);
    if (close === -1) break;
    ranges.push({ start: pattern.lastIndex, end: close });
    pattern.lastIndex = close + "</script>".length;
  }
  return ranges;
}

function unsafeFunctionRanges(source) {
  const ranges = [];
  const stack = [];
  for (let cursor = 0; cursor < source.length; cursor += 1) {
    if (["'", '"', "`"].includes(source[cursor])) {
      cursor = skipQuoted(source, cursor) - 1;
      continue;
    }
    if (source[cursor] === "{") {
      const prefix = source.slice(Math.max(0, cursor - 160), cursor);
      const opensFunction = /(?:=>\s*|function\*?\s*(?:[A-Za-z_$][\w$]*)?\s*\([^{};]*\)\s*)$/.test(prefix);
      stack.push({ start: cursor, unsafe: opensFunction || Boolean(stack.at(-1)?.unsafe) });
    } else if (source[cursor] === "}") {
      const block = stack.pop();
      if (block?.unsafe) ranges.push({ start: block.start, end: cursor + 1 });
    }
  }
  return ranges;
}

function isInsideRange(index, ranges) {
  return ranges.some((range) => index >= range.start && index < range.end);
}

function linePrefix(source, index) {
  const lineStart = source.lastIndexOf("\n", index - 1) + 1;
  return source.slice(lineStart, index);
}

function isDeclarationPrefix(prefix) {
  return /(?:^|\b)(?:function\*?|const|let|var|type|interface)\s*$/.test(prefix);
}

function isInlineSelector(argument) {
  const text = argument.trim();
  return text.startsWith("function") || /^\(?\s*[A-Za-z_$][\w$]*(?:\s*,\s*[A-Za-z_$][\w$]*)*\s*\)?\s*=>/.test(text);
}

function pushDirectSelectorDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  const unsafeRanges = unsafeFunctionRanges(maskedSource);
  const componentScriptRanges = isComponentFile(file) ? scriptRanges(maskedSource) : [];
  const selectorPattern = /\bselect[A-Z][A-Za-z0-9_$]*\s*(?:<[^>\n]+>\s*)?\(/g;
  let match;
  while ((match = selectorPattern.exec(maskedSource))) {
    const prefix = linePrefix(maskedSource, match.index);
    if (isDeclarationPrefix(prefix) || /\.\s*$/.test(prefix)) continue;
    const inFunction = isInsideRange(match.index, unsafeRanges) || /(?:=>|function\*?\b)/.test(prefix);
    const inComponentMarkup = isComponentFile(file) && !isInsideRange(match.index, componentScriptRanges);
    if (!inFunction && !inComponentMarkup) continue;
    const location = locationFor(source, match.index);
    if (isIgnored(directSelectorCallModeRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        directSelectorCallModeRule,
        file,
        source,
        match.index,
        "Bare selectFoo() creates a Svelte readable and is only safe at component init; use selectFoo.select(state) in callbacks/handlers or selectFoo.effect() in sagas."
      )
    );
  }
}

function pushWaitForDiagnostics({ diagnostics, file, source, maskedSource, isIgnored }) {
  if (!isSagaFile(file)) return;
  for (const call of findCalls(maskedSource, ["waitFor"])) {
    const firstArg = splitTopLevelArguments(call.args)[0];
    if (!firstArg || !isInlineSelector(firstArg.text)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(waitForNamedSelectorRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        waitForNamedSelectorRule,
        file,
        source,
        call.start,
        "waitFor must receive a named selector created by createSelector; inline selector lambdas are not supported."
      )
    );
  }
}

export function validateSelectorCallModeGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskStringLiterals(maskComments(source));
  pushDirectSelectorDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  pushWaitForDiagnostics({ diagnostics, file, source, maskedSource, isIgnored });
  return diagnostics;
}