import { diagnostic, locationFor, removeComments } from "./shared.mjs";

export const passThroughWrapperRule = "pass-through-wrapper";

function ignoreRulesAndReason(line, marker) {
  const index = line.indexOf(marker);
  if (index === -1) return undefined;
  const rest = line.slice(index + marker.length).trim();
  const [rulePart, reasonPart = ""] = rest.split("--");
  const rulesText = rulePart.trim().replace(/^[:=]/, "").trim();
  const rules = !rulesText ? new Set(["all"]) : new Set(rulesText.split(/[\s,]+/).filter(Boolean));
  return { rules, reason: reasonPart.trim() };
}

function hasReviewedCompatibilityReason(source, lineNumber) {
  const lines = source.split(/\r?\n/);
  const candidates = [...lines.filter((line) => line.includes("architecture-gate-ignore-file")), lines[lineNumber - 2] ?? "", lines[lineNumber - 1] ?? ""];
  for (const line of candidates) {
    const parsed = ignoreRulesAndReason(line, line.includes("architecture-gate-ignore-file") ? "architecture-gate-ignore-file" : "architecture-gate-ignore-next-line");
    if (!parsed?.rules.has("all") && !parsed?.rules.has(passThroughWrapperRule)) continue;
    if (/\b(compat|migration|legacy|sunset|remove|deprecat)/i.test(parsed.reason)) return true;
  }
  return false;
}

function isBarrelOrTypeFile(file) {
  return /(^|\/)index\.[cm]?[jt]sx?$/.test(file) || /-types\.[cm]?[jt]sx?$/.test(file);
}

function normalizedCode(source) {
  return removeComments(source)
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .join("\n");
}

function reExportOnlyIndex(source) {
  const clean = normalizedCode(source);
  if (!clean) return undefined;
  const statements = clean
    .split(/;\s*\n?|\n(?=export\s+(?:\*|\{))/)
    .map((statement) => statement.trim().replace(/;$/, ""))
    .filter(Boolean);
  if (statements.length === 0 || statements.length > 2) return undefined;
  if (!statements.every((statement) => /^export\s+(?:\*|\{[\s\S]*?\})\s+from\s+["']\.[^"']+["']$/.test(statement))) return undefined;
  const first = source.search(/export\s+(?:\*|\{[\s\S]*?\})\s+from\s+["']\.[^"']+["']/);
  return first === -1 ? 0 : first;
}

function delegationWrapperIndex(source) {
  const clean = normalizedCode(source);
  const importMatch = clean.match(/^import\s+\{\s*([A-Za-z_$][\w$]*)\s*\}\s+from\s+["']\.[^"']+["'];?\s*/);
  if (!importMatch) return undefined;
  const imported = importMatch[1];
  const rest = clean.slice(importMatch[0].length).trim();
  const functionPattern = new RegExp(`^export\\s+function\\s+[A-Za-z_$][\\w$]*\\s*\\(([^)]*)\\)\\s*\\{\\s*return\\s+${imported}\\s*\\(([^)]*)\\)\\s*;?\\s*\\}\\s*$`, "s");
  const constPattern = new RegExp(`^export\\s+const\\s+[A-Za-z_$][\\w$]*\\s*=\\s*\\(([^)]*)\\)\\s*=>\\s*${imported}\\s*\\(([^)]*)\\)\\s*;?\\s*$`, "s");
  if (!functionPattern.test(rest) && !constPattern.test(rest)) return undefined;
  const first = source.search(/export\s+(?:function|const)\s+/);
  return first === -1 ? 0 : first;
}

export function validatePassThroughWrapperGate({ file, source }) {
  if (isBarrelOrTypeFile(file)) return [];
  const index = reExportOnlyIndex(source) ?? delegationWrapperIndex(source);
  if (index === undefined) return [];
  const line = locationFor(source, index).line;
  if (hasReviewedCompatibilityReason(source, line)) return [];
  return [
    diagnostic(
      passThroughWrapperRule,
      file,
      source,
      index,
      "Pass-through wrappers/re-exports must be removed after refactors, or kept only with an architecture-gate-ignore reason documenting compatibility and sunset/removal conditions."
    ),
  ];
}