import { createIgnoreChecker, diagnostic, findCalls, isSagaFile, locationFor, maskComments, splitTopLevelArguments } from "./shared.mjs";

export const inlineSagaSelectorRule = "inline-saga-selector";

function isInlineSelector(argument) {
  const text = argument.trim();
  return text.startsWith("function") || /^\(?\s*[A-Za-z_$][\w$]*(?:\s*,\s*[A-Za-z_$][\w$]*)*\s*\)?\s*=>/.test(text);
}

export function validateSagaSelectorUsageGate({ file, source }) {
  if (!isSagaFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  for (const call of findCalls(maskComments(source), ["select"])) {
    const firstArg = splitTopLevelArguments(call.args)[0];
    if (!firstArg || !isInlineSelector(firstArg.text)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(inlineSagaSelectorRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        inlineSagaSelectorRule,
        file,
        source,
        call.start,
        "Inline saga selectors are anonymous and bypass named selector caching; create a selector and call selectFoo.effect() instead."
      )
    );
  }
  return diagnostics;
}