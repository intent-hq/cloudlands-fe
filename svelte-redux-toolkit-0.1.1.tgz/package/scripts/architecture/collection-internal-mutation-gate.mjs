import { createIgnoreChecker, diagnostic, lineStartIndex, maskComments } from "./shared.mjs";

export const collectionInternalMutationRule = "collection-internal-mutation";

function isAllowedCollectionInternalFile(file) {
  return file.endsWith("utils/collections/collection-utils.ts") || file.endsWith("utils/collections/collection-utils.js") || file.endsWith("utils/selectors/create-cached-selector.ts");
}

const mutationPatterns = [
  /\b[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*\.(map|ids|refsCount)(?:\s*(?:=|\+=|-=|\+\+|--)|\s*\[[^\]]+\]\s*(?:=|\+=|-=|\+\+|--)|\s*\.\s*(?:push|pop|shift|unshift|splice|sort|reverse|set|delete|clear)\s*\()/g,
  /delete\s+\b[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*\.(map|ids|refsCount)\s*\[/g,
];

export function validateCollectionInternalMutationGate({ file, source }) {
  if (isAllowedCollectionInternalFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const lines = maskComments(source).split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    for (const pattern of mutationPatterns) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(line))) {
        const lineNumber = index + 1;
        if (isIgnored(collectionInternalMutationRule, lineNumber)) continue;
        diagnostics.push(
          diagnostic(
            collectionInternalMutationRule,
            file,
            source,
            lineStartIndex(source, lineNumber) + match.index,
            `Collection internals ".${match[1]}" must not be mutated outside collection utilities; use collection helper functions so refs and IDs remain consistent.`
          )
        );
      }
    }
  }
  return diagnostics;
}