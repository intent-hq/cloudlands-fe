import { createIgnoreChecker, diagnostic, findCalls, locationFor, splitTopLevelArguments } from "./shared.mjs";

export const storeConstructorSagaMapRule = "store-constructor-saga-map";

function isNewStoreCall(source, call) {
  return /\bnew\s*$/.test(source.slice(0, call.start));
}

function argumentStart(source, baseIndex, argument) {
  const leadingWhitespace = argument.text.search(/\S/);
  return baseIndex + argument.offset + (leadingWhitespace === -1 ? 0 : leadingWhitespace);
}

function looksLikeConstructorSagaMap(argumentText) {
  const text = argumentText.trim();
  if (!text || text === "undefined" || text === "null") return false;
  if (text.startsWith("{")) return true;
  return /(?:^|[A-Za-z_$][\w$]*)(?:sagas?|sagaMap|sagaRegistry)$/i.test(text);
}

export function validateStoreSagaRegistrationGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];

  for (const call of findCalls(source, ["Store"])) {
    if (!isNewStoreCall(source, call)) continue;
    const secondArgument = splitTopLevelArguments(call.args)[1];
    if (!secondArgument || !looksLikeConstructorSagaMap(secondArgument.text)) continue;

    const index = argumentStart(source, call.argsStart, secondArgument);
    if (isIgnored(storeConstructorSagaMapRule, locationFor(source, index).line)) continue;
    diagnostics.push(
      diagnostic(
        storeConstructorSagaMapRule,
        file,
        source,
        index,
        "Store constructor saga maps are stale; create the Store with reducers/middleware only and start app sagas with store.runSaga(sagaFn) after init."
      )
    );
  }

  return diagnostics;
}