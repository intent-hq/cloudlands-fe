import { createIgnoreChecker, diagnostic, lineStartIndex, readBalanced } from "./shared.mjs";

export const nonSerializableStateTypeRule = "non-serializable-state-type";

const forbiddenTypes = new Set(["Date", "Map", "Set", "WeakMap", "WeakSet", "RegExp", "Promise", "Function", "Error", "Symbol"]);

function stateShapeMatches(source) {
  return [
    /export\s+type\s+([A-Za-z_$][\w$]*State)\s*=\s*\{/g,
    /export\s+interface\s+([A-Za-z_$][\w$]*State)\s*\{/g,
  ].flatMap((pattern) => {
    const matches = [];
    let match;
    while ((match = pattern.exec(source))) matches.push(match);
    return matches;
  });
}

function propertyTypeLines(body, startLine) {
  const properties = [];
  let depth = 0;
  const lines = body.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const match = depth === 0 ? line.match(/^\s*([A-Za-z_$][\w$]*|["'][^"']+["'])\??\s*:\s*([^;,]+)/) : undefined;
    if (match) properties.push({ name: match[1].replace(/^["']|["']$/g, ""), type: match[2], line: startLine + index, lineText: line });
    const cleanLine = line.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/, "").replace(/(['"`])(?:\\.|(?!\1).)*\1/g, "");
    for (const char of cleanLine) {
      if ("({[<".includes(char)) depth += 1;
      if (")}]>".includes(char)) depth = Math.max(0, depth - 1);
    }
  }
  return properties;
}

export function validateStateSerializationGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  for (const match of stateShapeMatches(source)) {
    const openIndex = source.indexOf("{", match.index);
    const shape = readBalanced(source, openIndex, "{", "}");
    if (!shape) continue;
    const startLine = source.slice(0, openIndex + 1).split(/\r?\n/).length;
    for (const property of propertyTypeLines(shape.body, startLine)) {
      const forbidden = [...property.type.matchAll(/\b(Date|Map|Set|WeakMap|WeakSet|RegExp|Promise|Function|Error|Symbol)\b/g)].find((typeMatch) => forbiddenTypes.has(typeMatch[1]));
      if (!forbidden || isIgnored(nonSerializableStateTypeRule, property.line)) continue;
      diagnostics.push(
        diagnostic(
          nonSerializableStateTypeRule,
          file,
          source,
          lineStartIndex(source, property.line) + property.lineText.indexOf(forbidden[1]),
          `Redux state field "${property.name}" uses non-serializable type "${forbidden[1]}" in ${match[1]}; store a plain serializable representation instead.`
        )
      );
    }
  }
  return diagnostics;
}