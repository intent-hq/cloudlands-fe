import { createIgnoreChecker, diagnostic, findActionTypeLiterals, locationFor, maskComments } from "./shared.mjs";

export const unnamespacedActionTypeRule = "unnamespaced-action-type";

export function validateActionNamespaceGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  for (const literal of findActionTypeLiterals(maskComments(source))) {
    const location = locationFor(source, literal.index);
    if (literal.value.includes("/") || isIgnored(unnamespacedActionTypeRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        unnamespacedActionTypeRule,
        file,
        source,
        literal.index,
        `Action type "${literal.value}" is not namespaced. Use "sliceName/actionName" so action streams stay globally owned.`
      )
    );
  }
  return diagnostics;
}