#!/usr/bin/env node

import { lstat, readdir, readFile } from "node:fs/promises";
import { extname, join, relative, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { validateLocalStorageGate } from "./local-storage-gate.mjs";
import { validateReduxApiBoundaryGate } from "./redux-api-boundary-gate.mjs";
import { validateSagaWatcherPatternsGate } from "./saga-watcher-patterns-gate.mjs";
import { validateSelectorCallModeGate } from "./selector-call-mode-gate.mjs";
import { validateStoreSagaRegistrationGate } from "./store-saga-registration-gate.mjs";
import { validateTestPatternsGate } from "./test-patterns-gate.mjs";

const defaultPaths = ["skills", "README.md", "docs"];
const ignoredDirectories = new Set([".git", "coverage", "dist", "node_modules"]);
const codeFenceLanguages = new Set(["js", "javascript", "jsx", "ts", "typescript", "tsx"]);

function normalizePath(path) {
  return path.replace(/\\/g, "/");
}

function markdownLocation(source, index) {
  const before = source.slice(0, index);
  const lines = before.split(/\r?\n/);
  return { line: lines.length, column: lines[lines.length - 1].length + 1 };
}

function extensionForLanguage(language) {
  if (language === "jsx") return ".jsx";
  if (language === "tsx") return ".tsx";
  if (language === "js" || language === "javascript") return ".js";
  return ".ts";
}

function codeFenceFileHint(source) {
  const firstLines = source.split(/\r?\n/).slice(0, 3);
  for (const line of firstLines) {
    const match = line.match(/^\s*\/\/\s*([A-Za-z0-9_./-]+\.(?:test\.)?[cm]?[jt]sx?)\s*$/);
    if (match) return match[1];
  }
  return undefined;
}

function isTestExample(source, hint = "") {
  return /(?:^|\.)test\.[cm]?[jt]sx?$/.test(hint) || /\b(?:describe|it|test|expect)\s*\(/.test(source) || /from\s+["']vitest["']/.test(source);
}

function isSagaExample(source, hint = "") {
  return /(?:^|[-/])sagas?(?:[-/.]|$)/i.test(hint) || /\b(?:function\*|yield\*?|takeEvery|takeLatest|takeLeading|waitFor)\b/.test(source) || /(?:window\.)?localStorage\s*\./.test(source);
}

function virtualFileForFence(markdownFile, fence, index) {
  const hint = codeFenceFileHint(fence.source);
  if (hint) return normalizePath(join("skill-example-fences", markdownFile, `${index}-${hint}`));
  const extension = extensionForLanguage(fence.language);
  if (isTestExample(fence.source)) return normalizePath(join("skill-example-fences", markdownFile, `${index}-example.test${extension}`));
  if (isSagaExample(fence.source)) return normalizePath(join("skill-example-fences", markdownFile, `${index}-example-saga${extension}`));
  return normalizePath(join("skill-example-fences", markdownFile, `${index}-example${extension}`));
}

function previousNonBlankLines(source, index, count) {
  const lines = source.slice(0, index).split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  return lines.slice(Math.max(0, lines.length - count));
}

function isIntentionalBadExample(markdownSource, fence) {
  const context = previousNonBlankLines(markdownSource, fence.start, 3).join("\n");
  const firstCodeLines = fence.source.split(/\r?\n/).slice(0, 4).join("\n");
  return /(?:^|\n)#+\s*.*(?:❌|wrong|bad)/i.test(context) || /(?:❌|\bWRONG\b|\bBAD\b)/i.test(firstCodeLines);
}

export function extractCodeFences(markdownSource) {
  const fences = [];
  const pattern = /^```([A-Za-z0-9_-]*)[^\r\n]*\r?\n([\s\S]*?)^```\s*$/gm;
  let match;
  while ((match = pattern.exec(markdownSource))) {
    const language = match[1].toLowerCase();
    if (!codeFenceLanguages.has(language)) continue;
    const sourceStart = match.index + match[0].indexOf(match[2]);
    fences.push({ language, source: match[2], start: match.index, sourceStart });
  }
  return fences;
}

async function collectMarkdownFiles(root, paths) {
  const files = [];
  async function visit(absolutePath) {
    let stat;
    try {
      stat = await lstat(absolutePath);
    } catch (error) {
      if (error?.code === "ENOENT") return;
      throw error;
    }
    if (stat.isDirectory()) {
      if (ignoredDirectories.has(absolutePath.split(/[\\/]/).pop())) return;
      const entries = await readdir(absolutePath);
      await Promise.all(entries.map((entry) => visit(join(absolutePath, entry))));
      return;
    }
    if (extname(absolutePath) === ".md") files.push(absolutePath);
  }
  for (const path of paths) await visit(resolve(root, path));
  return files.sort();
}

function mapDiagnostic(markdownFile, markdownSource, fence, diagnostic) {
  const relativeIndex = fence.source.split(/\r?\n/).slice(0, diagnostic.line - 1).join("\n").length;
  const lineOffset = diagnostic.line > 1 ? relativeIndex + 1 : 0;
  const location = markdownLocation(markdownSource, fence.sourceStart + lineOffset + diagnostic.column - 1);
  return {
    ...diagnostic,
    file: markdownFile,
    line: location.line,
    column: location.column,
    message: `${diagnostic.message} (in ${fence.language} code fence)`,
  };
}

export async function validateSkillExamples(options = {}) {
  const root = resolve(options.root ?? process.cwd());
  const paths = options.paths ?? defaultPaths;
  const markdownFiles = await collectMarkdownFiles(root, paths);
  const diagnostics = [];
  let scannedFences = 0;
  let skippedFences = 0;

  for (const file of markdownFiles) {
    const markdownSource = await readFile(file, "utf8");
    const markdownFile = normalizePath(relative(root, file));
    const fences = extractCodeFences(markdownSource);
    for (const [index, fence] of fences.entries()) {
      if (isIntentionalBadExample(markdownSource, fence)) {
        skippedFences += 1;
        continue;
      }
      scannedFences += 1;
      const virtualFile = virtualFileForFence(markdownFile, fence, index + 1);
      const testExample = isTestExample(fence.source, virtualFile);
      const gates = [validateLocalStorageGate, validateReduxApiBoundaryGate, validateSagaWatcherPatternsGate, validateStoreSagaRegistrationGate];
      if (testExample) gates.push(validateTestPatternsGate);
      else gates.push(validateSelectorCallModeGate);
      for (const gate of gates) {
        diagnostics.push(...gate({ file: virtualFile, source: fence.source }).map((diagnostic) => mapDiagnostic(markdownFile, markdownSource, fence, diagnostic)));
      }
    }
  }

  diagnostics.sort((a, b) => a.file.localeCompare(b.file) || a.line - b.line || a.rule.localeCompare(b.rule));
  return { files: markdownFiles.map((file) => normalizePath(relative(root, file))), scannedFences, skippedFences, diagnostics };
}

export function formatSkillExampleDiagnostics(result) {
  if (result.diagnostics.length === 0) return "[skill-example-validation] no skill/doc example violations found";
  return result.diagnostics.map((diagnostic) => `[${diagnostic.rule}] ${diagnostic.file}:${diagnostic.line}:${diagnostic.column} ${diagnostic.message}`).join("\n\n");
}

function parseCliArgs(argv) {
  const options = { paths: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--root") options.root = argv[++index];
    else if (arg === "--json") options.json = true;
    else options.paths.push(arg);
  }
  if (options.paths.length === 0) delete options.paths;
  return options;
}

export async function main(argv = process.argv.slice(2)) {
  const options = parseCliArgs(argv);
  const result = await validateSkillExamples(options);
  if (options.json) console.log(JSON.stringify(result, null, 2));
  else {
    console.log(formatSkillExampleDiagnostics(result));
    console.log(`[skill-example-validation] scanned ${result.files.length} Markdown files and ${result.scannedFences} TypeScript/JavaScript code fences; skipped ${result.skippedFences} intentional noncompliant examples`);
  }
  return result.diagnostics.length === 0 ? 0 : 1;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(await main());
}