import { createIgnoreChecker, diagnostic, findCalls, isSagaFile, locationFor, maskComments, splitTopLevelArguments } from "./shared.mjs";

export const autoForkingChannelHelperRule = "auto-forking-channel-helper";
export const rawChannelCleanupRule = "raw-channel-cleanup";

const autoForkingHelpers = new Set(["takeEveryFromSelector", "takeLatestFromSelector", "takeLeadingFromSelector"]);

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function hasDetectableClose(source, channelName) {
  return new RegExp(`\\b${escapeRegex(channelName)}\\s*\\.\\s*close\\s*\\(`).test(source);
}

export function validateChannelLifecycleGate({ file, source }) {
  if (!isSagaFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskComments(source);

  for (const call of findCalls(maskedSource, ["fork"])) {
    const firstArg = splitTopLevelArguments(call.args)[0]?.text.trim() ?? "";
    const helper = firstArg.match(/^([A-Za-z_$][\w$]*)\b/)?.[1];
    if (!autoForkingHelpers.has(helper)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(autoForkingChannelHelperRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        autoForkingChannelHelperRule,
        file,
        source,
        call.start,
        `${helper} already forks and returns a Task; call it with yield* instead of wrapping it in fork().`
      )
    );
  }

  const rawChannelPattern = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:yield\*\s*)?(?:createChannelFromSelector|eventChannel)\s*(?:<[^>\n]+>\s*)?\(/g;
  let match;
  while ((match = rawChannelPattern.exec(maskedSource))) {
    const channelName = match[1];
    if (hasDetectableClose(maskedSource, channelName)) continue;
    const location = locationFor(source, match.index);
    if (isIgnored(rawChannelCleanupRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        rawChannelCleanupRule,
        file,
        source,
        match.index,
        `Raw channel "${channelName}" is created without a detectable ${channelName}.close(); wrap manual channel use in try/finally or use the auto-cleanup channel helpers.`
      )
    );
  }

  return diagnostics;
}