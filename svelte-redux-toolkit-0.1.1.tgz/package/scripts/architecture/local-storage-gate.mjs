import { createIgnoreChecker, diagnostic, isComponentFile, isSagaFile, lineStartIndex, maskComments } from "./shared.mjs";

export const directLocalStorageRule = "direct-local-storage-usage";

function isAllowedLocalStorageHelper(file) {
  return file.endsWith("examples/utils/safe-local-storage-saga.ts") || file.endsWith("examples/utils/safe-local-storage-saga.js");
}

export function validateLocalStorageGate({ file, source }) {
  if (isAllowedLocalStorageHelper(file)) return [];
  const checkBareGlobal = isComponentFile(file) || isSagaFile(file);
  const pattern = checkBareGlobal ? /(?:window\.)?localStorage\b/g : /window\.localStorage\b/g;
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const lines = maskComments(source).split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    let match;
    while ((match = pattern.exec(line))) {
      const lineNumber = index + 1;
      if (isIgnored(directLocalStorageRule, lineNumber)) continue;
      diagnostics.push(
        diagnostic(
          directLocalStorageRule,
          file,
          source,
          lineStartIndex(source, lineNumber) + match.index,
          "Direct localStorage usage bypasses the safe saga helpers; use getLocalStorageItem/setLocalStorageItem/getLocalStorageJSON/setLocalStorageJSON."
        )
      );
    }
  }
  return diagnostics;
}