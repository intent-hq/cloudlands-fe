import { createIgnoreChecker, diagnostic, isSagaFile, lineStartIndex, maskComments } from "./shared.mjs";

export const typedSagaYieldStarRule = "typed-saga-yield-star";

const typedEffectPattern = /\byield\s+(?!\*)(?:call|put|take|fork|spawn|delay|race|all|select|cancel|cancelled|takeEvery|takeLatest|takeLeading|getContext|setContext|actionChannel|join)\s*(?:<[^>\n]+>\s*)?\(/g;
const selectorEffectPattern = /\byield\s+(?!\*)[A-Za-z_$][\w$]*\.effect\s*\(/g;

function isTypedSagaScope(file, source) {
  return isSagaFile(file) || /from\s+["']typed-redux-saga["']/.test(source);
}

export function validateSagaEffectStyleGate({ file, source }) {
  if (!isTypedSagaScope(file, source)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const lines = maskComments(source).split(/\r?\n/);

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const lineNumber = index + 1;
    for (const pattern of [typedEffectPattern, selectorEffectPattern]) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(line))) {
        if (isIgnored(typedSagaYieldStarRule, lineNumber)) continue;
        diagnostics.push(
          diagnostic(
            typedSagaYieldStarRule,
            file,
            source,
            lineStartIndex(source, lineNumber) + match.index,
            "typed-redux-saga effects must be delegated with yield*; bare yield returns the effect descriptor instead of the typed result."
          )
        );
      }
    }
  }

  return diagnostics;
}