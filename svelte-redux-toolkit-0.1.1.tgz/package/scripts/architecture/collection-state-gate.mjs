import { createIgnoreChecker, diagnostic, lineStartIndex, readBalanced } from "./shared.mjs";

export const collectionStateShapeRule = "collection-state-shape";

const primitiveOrIdTypePattern = /^(?:string|number|boolean|bigint|symbol|null|undefined|[A-Za-z_$][\w$]*(?:Id|ID)|Id|ID)$/;

function stateShapeMatches(source) {
  return [/export\s+type\s+([A-Za-z_$][\w$]*State)\s*=\s*\{/g, /export\s+interface\s+([A-Za-z_$][\w$]*State)\s*\{/g].flatMap((pattern) => {
    const matches = [];
    let match;
    while ((match = pattern.exec(source))) matches.push(match);
    return matches;
  });
}

function propertyTypeLines(body, startLine) {
  const properties = [];
  let depth = 0;
  const lines = body.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const match = depth === 0 ? line.match(/^\s*([A-Za-z_$][\w$]*|["'][^"']+["'])\??\s*:\s*([^;,]+)/) : undefined;
    if (match) properties.push({ name: match[1].replace(/^["']|["']$/g, ""), type: match[2], line: startLine + index, lineText: line });
    const cleanLine = line.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/, "").replace(/(['"`])(?:\\.|(?!\1).)*\1/g, "");
    for (const char of cleanLine) {
      if ("({[<".includes(char)) depth += 1;
      if (")}]>".includes(char)) depth = Math.max(0, depth - 1);
    }
  }
  return properties;
}

function arrayElementType(typeText) {
  const normalized = typeText.replace(/\breadonly\s+/g, "").trim();
  const bracketMatch = normalized.match(/^([^|&;,]+?)\s*\[\]/);
  if (bracketMatch) return bracketMatch[1].trim();
  const genericMatch = normalized.match(/^(?:Array|ReadonlyArray)<\s*([^>]+)\s*>/);
  if (genericMatch) return genericMatch[1].trim();
  return undefined;
}

function isAllowedOrderingArray(elementType) {
  return elementType
    .split("|")
    .map((part) => part.trim())
    .every((part) => primitiveOrIdTypePattern.test(part));
}

function initialStateTypeAssertions(source) {
  const assertions = [];
  const initialStatePattern = /(?:export\s+)?const\s+([A-Za-z_$][\w$]*initialState|initialState)\s*(?::[^=]+)?=\s*\{/gi;
  let match;
  while ((match = initialStatePattern.exec(source))) {
    const openIndex = source.indexOf("{", match.index);
    const shape = readBalanced(source, openIndex, "{", "}");
    if (!shape) continue;
    const startLine = source.slice(0, openIndex + 1).split(/\r?\n/).length;
    const lines = shape.body.split(/\r?\n/);
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const assertion = line.match(/^\s*([A-Za-z_$][\w$]*|["'][^"']+["'])\s*:\s*\[\]\s+as\s+([^,}]+)/);
      if (assertion) assertions.push({ name: assertion[1].replace(/^["']|["']$/g, ""), type: assertion[2], line: startLine + index, lineText: line });
    }
  }
  return assertions;
}

export function validateCollectionStateGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const properties = [];

  for (const match of stateShapeMatches(source)) {
    const openIndex = source.indexOf("{", match.index);
    const shape = readBalanced(source, openIndex, "{", "}");
    if (!shape) continue;
    const startLine = source.slice(0, openIndex + 1).split(/\r?\n/).length;
    properties.push(...propertyTypeLines(shape.body, startLine).map((property) => ({ ...property, shapeName: match[1] })));
  }
  properties.push(...initialStateTypeAssertions(source).map((property) => ({ ...property, shapeName: "initialState" })));

  for (const property of properties) {
    const elementType = arrayElementType(property.type);
    if (!elementType || isAllowedOrderingArray(elementType) || isIgnored(collectionStateShapeRule, property.line)) continue;
    diagnostics.push(
      diagnostic(
        collectionStateShapeRule,
        file,
        source,
        lineStartIndex(source, property.line) + property.lineText.indexOf(property.type.trim()),
        `Redux state field "${property.name}" in ${property.shapeName} stores "${elementType}" objects in an array; use Collection<T, K> plus primitive/ID ordering arrays instead.`
      )
    );
  }

  return diagnostics;
}