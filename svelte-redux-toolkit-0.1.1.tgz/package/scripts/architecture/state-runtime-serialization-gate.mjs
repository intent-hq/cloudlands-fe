import { createIgnoreChecker, diagnostic, lineStartIndex, maskComments, readBalanced } from "./shared.mjs";

export const nonSerializableInitialStateRule = "non-serializable-initial-state";
export const nondeterministicReducerStateRule = "nondeterministic-reducer-state";

const runtimeStatePatterns = [
  { label: "Date", pattern: /\bnew\s+Date\s*\(/g },
  { label: "Map", pattern: /\bnew\s+Map\s*\(/g },
  { label: "Set", pattern: /\bnew\s+Set\s*\(/g },
  { label: "WeakMap", pattern: /\bnew\s+WeakMap\s*\(/g },
  { label: "WeakSet", pattern: /\bnew\s+WeakSet\s*\(/g },
  { label: "RegExp", pattern: /\bnew\s+RegExp\s*\(/g },
  { label: "Error", pattern: /\bnew\s+Error\s*\(/g },
  { label: "Promise", pattern: /\bnew\s+Promise\s*\(/g },
  { label: "function", pattern: /(?:=>|\bfunction\s*(?:[A-Za-z_$][\w$]*)?\s*\()/g },
];

const nondeterministicPatterns = [
  { label: "Date.now", pattern: /\bDate\.now\s*\(/g },
  { label: "new Date", pattern: /\bnew\s+Date\s*\(/g },
  { label: "Math.random", pattern: /\bMath\.random\s*\(/g },
  { label: "randomUUID", pattern: /\b(?:crypto\.)?randomUUID\s*\(/g },
];

function isReducerStateFile(file) {
  return /(?:^|\/)[^/]*(?:reducer|slice)\.[cm]?[jt]sx?$/.test(file) || /(?:^|\/)[^/]*-slice\.[cm]?[jt]sx?$/.test(file);
}

function initialStateLiterals(source) {
  const literals = [];
  const initialStatePattern = /(?:export\s+)?const\s+([A-Za-z_$][\w$]*initialState|initialState)\s*(?::[^=]+)?=\s*\{/gi;
  let match;
  while ((match = initialStatePattern.exec(source))) {
    const openIndex = source.indexOf("{", match.index);
    const shape = readBalanced(source, openIndex, "{", "}");
    if (shape) literals.push({ name: match[1], body: shape.body, bodyStart: openIndex + 1 });
  }
  return literals;
}

function pushPatternDiagnostics({ diagnostics, rule, file, source, text, offset, patterns, messageFor, isIgnored }) {
  for (const { label, pattern } of patterns) {
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(text))) {
      const index = offset + match.index;
      const line = source.slice(0, index).split(/\r?\n/).length;
      if (isIgnored(rule, line)) continue;
      diagnostics.push(diagnostic(rule, file, source, index, messageFor(label)));
    }
  }
}

export function validateStateRuntimeSerializationGate({ file, source }) {
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  const maskedSource = maskComments(source);

  for (const literal of initialStateLiterals(maskedSource)) {
    pushPatternDiagnostics({
      diagnostics,
      rule: nonSerializableInitialStateRule,
      file,
      source,
      text: literal.body,
      offset: literal.bodyStart,
      patterns: runtimeStatePatterns,
      isIgnored,
      messageFor: (label) => `initialState "${literal.name}" creates non-serializable runtime value "${label}"; store plain serializable data instead.`,
    });
    pushPatternDiagnostics({
      diagnostics,
      rule: nondeterministicReducerStateRule,
      file,
      source,
      text: literal.body,
      offset: literal.bodyStart,
      patterns: nondeterministicPatterns,
      isIgnored,
      messageFor: (label) => `initialState "${literal.name}" uses nondeterministic value "${label}"; derive timestamps/ids outside reducer state initialization.`,
    });
  }

  if (!isReducerStateFile(file)) return diagnostics;
  const lines = maskedSource.split(/\r?\n/);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    for (const { label, pattern } of nondeterministicPatterns) {
      pattern.lastIndex = 0;
      if (!pattern.test(line)) continue;
      const lineNumber = index + 1;
      if (isIgnored(nondeterministicReducerStateRule, lineNumber)) continue;
      diagnostics.push(
        diagnostic(
          nondeterministicReducerStateRule,
          file,
          source,
          lineStartIndex(source, lineNumber) + line.search(/\S/),
          `Reducer/slice state uses nondeterministic value "${label}"; create timestamps/random IDs in action preparation or saga code, not reducers.`
        )
      );
    }
  }

  return diagnostics;
}