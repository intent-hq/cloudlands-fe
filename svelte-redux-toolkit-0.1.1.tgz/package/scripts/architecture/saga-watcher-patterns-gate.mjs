import { createIgnoreChecker, diagnostic, findCalls, isSagaFile, locationFor, maskComments, splitTopLevelArguments } from "./shared.mjs";

export const sagaWatcherActionTypeRule = "saga-watcher-action-type";

export function validateSagaWatcherPatternsGate({ file, source }) {
  if (!isSagaFile(file)) return [];
  const isIgnored = createIgnoreChecker(source);
  const diagnostics = [];
  for (const call of findCalls(maskComments(source), ["take", "takeEvery", "takeLatest", "takeLeading"])) {
    const firstArg = splitTopLevelArguments(call.args)[0]?.text ?? "";
    if (!/\.type\b/.test(firstArg)) continue;
    const location = locationFor(source, call.start);
    if (isIgnored(sagaWatcherActionTypeRule, location.line)) continue;
    diagnostics.push(
      diagnostic(
        sagaWatcherActionTypeRule,
        file,
        source,
        call.start,
        `${call.name} should receive action creators directly, not .type strings, so typed-redux-saga preserves action typing.`
      )
    );
  }
  return diagnostics;
}