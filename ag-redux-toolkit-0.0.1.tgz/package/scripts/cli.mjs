#!/usr/bin/env node

import { realpathSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import { cleanupSkillsFromProject } from "./cleanup-skills.mjs";
import { installIntentSkillGuidance } from "./postinstall.mjs";
import { main as validateArchitectureMain } from "./validate-architecture.mjs";

const binaryName = "ag-redux-toolkit";

function stripNpmSeparator(args) {
  return args[0] === "--" ? args.slice(1) : args;
}

export function helpText(name = binaryName) {
  return `Usage:
  ${name} <command> [options]

Commands:
  install-skills             Copy packaged AI skills into .agents/skills/
  cleanup-skills             Remove package-owned copied skills from .agents/skills/
  validate-architecture      Run architecture validation against the current project
  help                       Show this help text

	Installed app invocation examples:
	  ./node_modules/.bin/${name} help
	  npm exec -- ${name} validate-architecture
	  npx ${name} install-skills

	Source checkout invocation:
	  node scripts/cli.mjs help

	If npm package invocation is silent, verify the installed bin exists at
	./node_modules/.bin/${name}; source checkouts are not linked automatically.
`;
}

export async function runCli(argv = process.argv.slice(2), options = {}) {
  const {
    cleanup = cleanupSkillsFromProject,
    cwd = process.cwd,
    install = installIntentSkillGuidance,
    logger = console,
    stderr = process.stderr,
    stdout = process.stdout,
    validateArchitecture = validateArchitectureMain,
  } = options;
  const [command, ...args] = argv;

  if (!command || command === "help" || command === "--help" || command === "-h") {
    stdout.write(helpText());
    return 0;
  }

  if (command === "install-skills") {
    try {
      install({ projectRoot: cwd(), logger });
    } catch (error) {
      logger.warn(`[ag-redux-toolkit] install-skills warning: ${error.message}`);
    }
    return 0;
  }

  if (command === "cleanup-skills") {
    try {
      cleanup({ projectRoot: cwd(), logger });
    } catch (error) {
      logger.warn(`[ag-redux-toolkit] cleanup-skills warning: ${error.message}`);
    }
    return 0;
  }

  if (command === "validate-architecture") {
    return validateArchitecture(stripNpmSeparator(args));
  }

  stderr.write(`[ag-redux-toolkit] Unknown command: ${command}\n\n`);
  stdout.write(helpText());
  return 1;
}

export function isCliEntrypoint(metaUrl = import.meta.url, argvPath = process.argv[1]) {
  if (!argvPath) return false;

  try {
    return realpathSync(fileURLToPath(metaUrl)) === realpathSync(argvPath);
  } catch {
    return metaUrl === pathToFileURL(argvPath).href;
  }
}

if (isCliEntrypoint()) {
  try {
    process.exit(await runCli());
  } catch (error) {
    console.error(`[ag-redux-toolkit] ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}