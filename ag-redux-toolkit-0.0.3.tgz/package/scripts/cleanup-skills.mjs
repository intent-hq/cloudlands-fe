#!/usr/bin/env node

/**
 * Explicit cleanup script — removes AI skill files copied by ag-redux-toolkit
 * into the consuming project's .agents/skills/ directory.
 *
 * Safety guarantees:
 *  - Only removes package-owned skill directories
 *  - Excludes generated skills/_artifacts content
 *  - No-op when run outside node_modules or when no package-owned skills exist
 *  - Never crashes — logs warnings and exits 0
 */

import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import {
  defaultPackageRoot,
  findConsumerProjectRoot,
	getPackageOwnedSkillNames,
  getPackagedSkillInventory,
  removePackageOwnedSkillCopies,
} from "./postinstall.mjs";

export function cleanupSkillsFromProject({ packageRoot = defaultPackageRoot, projectRoot, logger = console } = {}) {
  const resolvedProjectRoot = projectRoot ?? findConsumerProjectRoot({ packageRoot });
  if (!resolvedProjectRoot) {
		logger.log(
			"[ag-redux-toolkit] cleanup-skills skipped: package is not installed under a consumer node_modules directory; no skill files were removed."
		);
    return { removed: 0, skipped: true, reason: "not-installed-dependency" };
  }

  const skillsSrc = resolve(packageRoot, "skills");
  const skillsDest = resolve(resolvedProjectRoot, ".agents", "skills");

	if (!existsSync(skillsSrc)) {
		logger.log("[ag-redux-toolkit] cleanup-skills skipped: packaged skills were not found; no skill files were removed.");
		return { removed: 0, skipped: true, reason: "missing-skills" };
	}

	if (!existsSync(skillsDest)) {
		logger.log("[ag-redux-toolkit] cleanup-skills found no .agents/skills directory; no skill files were removed.");
    return { removed: 0, skipped: true, reason: "missing-skills" };
  }

  const inventory = getPackagedSkillInventory(skillsSrc);
  const { removed, pruned } = removePackageOwnedSkillCopies({
    skillsDest,
    packagedFiles: inventory.files,
	  skillNames: getPackageOwnedSkillNames(inventory.skillNames),
    removeCurrent: true,
  });

  if (removed > 0 || pruned > 0) {
			logger.log(
				`[ag-redux-toolkit] cleanup-skills removed package-owned AI skills from .agents/skills/ (${removed} files removed, ${pruned} empty dirs pruned).`
			);
	} else {
		logger.log("[ag-redux-toolkit] cleanup-skills found no package-owned copied skill files; no changes were made.");
  }

  return { removed, pruned, skipped: removed === 0 && pruned === 0 };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    cleanupSkillsFromProject();
  } catch (err) {
    console.warn(`[ag-redux-toolkit] cleanup warning: ${err.message}`);
    process.exit(0);
  }
}