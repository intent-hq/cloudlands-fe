# Installation, Cleanup, and Validation

This package has two install contexts with different expectations: consumer apps install it from npm, while maintainers validate this repository from a clean checkout.

## Consumer install

Install the package and its required peer dependencies in a Svelte 5 project:

```bash
npm install ag-redux-toolkit redux redux-saga typed-redux-saga fast-equals
```

`svelte@^5` is also required as a peer dependency and is normally already present in a Svelte app. For saga tests that follow this repository's examples, install the optional test helper:

```bash
npm install -D redux-saga-test-plan
```

## Explicit skill copy

Installing `ag-redux-toolkit` as a dependency does not copy Skills automatically. Copy or refresh packaged AI skills only when an agent or developer explicitly runs the package maintenance command. In this repository's source checkout, use:

```bash
npm run install:skills
```

The explicit skill installation command:

- changes to the consuming project root before doing any project writes;
- copies the selected packaged AI skill bundle into the consuming project root at `.agents/skills/`;
- removes stale package-owned files in the selected bundle scope before copying current skills;
- preserves unrelated project or third-party skills under `.agents/skills/`;
- excludes generated package artifacts such as `skills/_artifacts`;
- no-ops when the package is not installed under a consumer `node_modules` directory;
- logs warnings instead of failing the command.

This keeps package installation side-effect free while still letting humans and AI agents discover and load the same package-specific implementation guidance when requested.

## Consumer package CLI

Consuming apps should run package maintenance commands from the app root after the package has been installed and its bin has been linked. The most direct check is the installed bin path; it should print help immediately. Standard npm package invocation forms are also supported when npm can resolve the installed local bin:

```bash
./node_modules/.bin/ag-redux-toolkit help
npm exec -- ag-redux-toolkit help
npx ag-redux-toolkit
npx ag-redux-toolkit help
npx ag-redux-toolkit install-skills:react
npx ag-redux-toolkit install-skills:svelte
npx ag-redux-toolkit install-skills:streaming
npx ag-redux-toolkit install-skills
npx ag-redux-toolkit cleanup-skills
npx ag-redux-toolkit validate-architecture
```

Running `npx ag-redux-toolkit` with no command prints the same help text. Use the domain-specific install command that matches the selected Store family when an agent or developer needs only one package skill bundle:

| Command | Copied package-owned skills |
| --- | --- |
| `npx ag-redux-toolkit install-skills:react` | root `SKILL.md`, `setup`, `core`, and `react` |
| `npx ag-redux-toolkit install-skills:svelte` | root `SKILL.md`, `setup`, `core`, and `svelte` |
| `npx ag-redux-toolkit install-skills:streaming` | root `SKILL.md`, `setup`, `core`, and `streaming` |
| `npx ag-redux-toolkit install-skills:core` | root `SKILL.md`, `setup`, and `core` |
| `npx ag-redux-toolkit install-skills` or `npx ag-redux-toolkit install-skills:all` | the complete all-skills bundle |

Domain-specific installs refresh stale package-owned files only for their selected bundle scope, preserve unrelated project or third-party skills, and preserve non-selected package skill families. Use the all-skills command when the consuming app or repository intentionally needs every package skill family refreshed. Use `cleanup-skills` to remove package-owned copied `.agents/skills/` folders before uninstalling. Maintenance commands print copied, updated, skipped, removed, or no-op output so they should not appear silent. Use `validate-architecture` from the app root to run the packaged architecture validator against app code.

If npm package invocation appears to do nothing, verify `./node_modules/.bin/ag-redux-toolkit` exists in the consuming app and run `./node_modules/.bin/ag-redux-toolkit help` directly. If that file is missing, the package is not installed or the package manager has not linked its bin in that app; reinstall or repair the local package install before retrying. In this repository's source checkout, `npx`/`npm exec` package-name invocations are not a valid smoke test because the package bin is not linked automatically; use `node scripts/cli.mjs help` for source-checkout validation.

## Explicit cleanup and uninstall

npm 7+ does not run dependency uninstall lifecycle scripts, so uninstalling the package does not automatically remove copied skill files. Run cleanup first, then uninstall:

```bash
npm uninstall ag-redux-toolkit
npm uninstall redux redux-saga typed-redux-saga fast-equals # only if your app no longer uses them
```

The package keeps a cleanup command for package-owned files copied into `.agents/skills/`:

```bash
npx ag-redux-toolkit cleanup-skills
# or: npm exec -- ag-redux-toolkit cleanup-skills
```

That helper removes package-owned copied skills and leaves unrelated `.agents/skills` content alone. Remove optional test dependencies only if your app does not use them elsewhere:

```bash
npm uninstall -D redux-saga-test-plan
```

If an older package has already been uninstalled, manually remove only package-owned skill files and folders you no longer need:

- `.agents/skills/SKILL.md`
- `.agents/skills/setup`
- `.agents/skills/svelte`
- `.agents/skills/core`
- `.agents/skills/streaming`
- `.agents/skills/svelte-redux-toolkit` (legacy `svelte-redux-toolkit` installs)
- `.agents/skills/init-svelte-redux-toolkit` (legacy `svelte-redux-toolkit` installs)
- `.agents/skills/migrate-to-svelte-redux-toolkit` (legacy `svelte-redux-toolkit` installs)
- `.agents/skills/svelte/setup` (legacy setup path from older package versions)
- `.agents/skills/svelte/migration`

Do not delete `.agents/skills` as a whole unless you are certain it contains no project or third-party skills you want to keep.

## Maintainer validation

Maintainers should validate from the repository root with the committed npm lockfile:

```bash
npm ci
npm run validate:architecture
npm test
npm run build
npm run validate:release
```

Use `npm ci` for a clean local dependency baseline. Do not substitute consumer install or uninstall commands for release validation; those commands exercise a downstream app workflow and may update copied `.agents/skills/` content outside the repository validation path.

Run `npm run validate:architecture` before accepting or releasing changes that
touch Redux state, actions, selectors, sagas, or the skills/docs governing those areas. A
passing architecture gate exits 0 and prints
`[architecture-validation] no architecture gate violations found`; any listed
violation must be fixed or justified with the documented gate ignore comments
before release validation can pass.