# ag-redux-toolkit

![AG Redux Toolkit logo](./ag.png)

> Predictable Redux + Saga state management for Svelte readables, React signals, and observable consumers.

`ag-redux-toolkit` helps teams move shared state, async workflows, and derived data out of ad hoc callers and into explicit, testable Redux + Saga building blocks. It supports three public usage modes: Svelte/SvelteKit apps that want Svelte-readable selectors, React apps that want Preact React signal selectors plus component-friendly `.use(...)` reads, and Node, server, worker, test, or other streaming consumers that want Kefir/observable selectors. It is a custom package; it is not the official Redux Toolkit and does not use RTK APIs such as `createSlice`, `configureStore`, or `createAsyncThunk`.

## What problems does it solve?

Local component or script state is great for isolated UI and one-off logic. As an app or service grows, teams often need a more structured home for data that is shared across routes, loaded asynchronously, reused by services, streamed to non-Svelte consumers, or updated by long-running workflows.

Use this package when you want to:

- Keep shared application state in one predictable Redux store.
- Put API calls, subscriptions, timers, persistence, and other side effects in sagas instead of components.
- Read derived state through selectors that fit the caller: Svelte readables for Svelte components, Preact React signals or React `.use(...)` reads for React UIs, Kefir streams for observable consumers, `.select(...)` for direct state reads, and `.effect(...)` for sagas.
- Avoid unnecessary selector work with proxy-based tracking: selectors record the exact state paths they read, so unrelated state changes can skip needless recomputation and renders.
- Keep selector updates smooth under heavy store activity: readable, signal, and streaming selectors schedule and coalesce updates near frame rate, so a store changing every 1ms does not have to force UI or stream consumer work every 1ms.
- Model entity-heavy state with normalized collection helpers.
- Use documented debugging patterns for serializability-focused state modeling and dispatch/store access outside component code.
- Give humans and AI agents the same documented patterns for setup, migration, testing, and review.

## Installation

Install the package and its shared Redux/Saga peer dependencies in your app or package:

```bash
npm install ag-redux-toolkit redux redux-saga typed-redux-saga fast-equals
```

`svelte@^5` is also a peer dependency because the Svelte-readable entrypoint ships in the package; Svelte apps and frameworks normally provide it. `ReactStore` consumers should use it from React apps that can load `@preact/signals-react` signals. StreamingStore-only consumers can use the Node/non-Svelte APIs at runtime, but should still satisfy package peer dependencies for package-manager compatibility.

For saga tests, the docs use `redux-saga-test-plan` as an optional dev dependency:

```bash
npm install -D redux-saga-test-plan
```

### Manual Skills installation

Installing this package leaves a consuming project's Skills untouched. To install the packaged Skills, run the Skills CLI from the consuming project root:

```bash
npx skills add augmentcode/ag-redux-toolkit
```

This copies the repository's Skills into `.agents/skills/` only when you explicitly run the command.

From this repository's source checkout, maintainers can manually refresh the repo-local packaged Skills with `npm run install:skills`; this script is never run automatically during package installation. To remove only package-owned repo-local Skills copies, run `npm run cleanup:skills` manually.

### Package CLI

After installation, consuming apps can run the package binary from the app root. The most direct installed-bin check is `./node_modules/.bin/ag-redux-toolkit help`; it should print help immediately. Standard npm package invocation forms are also supported when npm can resolve the installed local bin. Running the binary with no command, or with `help`, prints the supported commands.

```bash
./node_modules/.bin/ag-redux-toolkit help
npm exec -- ag-redux-toolkit help
npx ag-redux-toolkit
npx ag-redux-toolkit help
npx ag-redux-toolkit install-skills:react
npx ag-redux-toolkit install-skills:svelte
npx ag-redux-toolkit install-skills:streaming
npx ag-redux-toolkit install-skills
npx ag-redux-toolkit cleanup-skills
npx ag-redux-toolkit validate-architecture
```

Use the smallest package-local skill install command that matches the consuming app's Store family: `install-skills:react` copies the root router plus `setup`, `core`, and `react`; `install-skills:svelte` copies the root router plus `setup`, `core`, and `svelte`; `install-skills:streaming` copies the root router plus `setup`, `core`, and `streaming`. Use `install-skills` (or the explicit `install-skills:all` alias) only when the app or repository needs the complete all-skills bundle. Domain-specific installs refresh stale package-owned files for the selected bundle scope and leave unrelated project, third-party, and non-selected package skill families alone; the all-skills flow refreshes all package-owned skill families while still preserving unrelated skills. Use `cleanup-skills` to remove package-owned `.agents/skills/` copies before uninstalling. These maintenance commands run only when invoked manually and print copied, updated, skipped, removed, or no-op output so they should not appear silent. In this repository's source checkout, use the manual-only `npm run install:skills` and `npm run cleanup:skills` scripts for the same repo-local maintenance flow; they are never invoked automatically by package installation. Use `validate-architecture` from an app root to run the packaged architecture validator against that app.

Architecture ESLint checks are public package API under `ag-redux-toolkit/eslint-plugins`. Parent projects should import the static `recommended` flat-config value from that root entrypoint, or `core`/`full` when they intentionally need a narrower or exhaustive named set. These root configs use the `ag-redux-toolkit/<rule-id>` namespace, keep excluded rules present as `off`, and enable selected rules as `warn`. `plugins` exposes the named per-rule config map for selected config composition. Extend/map imported configs locally when custom files or severities are needed. Retained standalone plugin subpaths under `ag-redux-toolkit/eslint-plugins/plugins` remain lower-level selected-rule surfaces; the root entrypoint does not export raw plugin objects, helper builders, compatibility aliases, source/test file constants, or customization shims. The older `ag-redux-toolkit/eslint-architecture` specifiers have been removed; downstream configs must use `/eslint-plugins` only.

If npm package invocation appears to do nothing, verify `./node_modules/.bin/ag-redux-toolkit` exists in the consuming app and run `./node_modules/.bin/ag-redux-toolkit help` directly. If that file is missing, the package is not installed or the package manager has not linked its bin in that app; reinstall or repair the local package install before retrying. In this repository's source checkout, `npx`/`npm exec` package-name invocations are not a valid smoke test because the package bin is not linked automatically; use `node scripts/cli.mjs help` for source-checkout validation.

## Uninstall and skill cleanup

Package uninstall does not remove manually installed or package-copied skill files. Run cleanup first if you used the package-local maintenance command, then uninstall packages you no longer use:

```bash
npm uninstall ag-redux-toolkit
npm uninstall redux redux-saga typed-redux-saga fast-equals # only if your app no longer uses them
```

Run the packaged cleanup command before uninstalling. It removes only package-owned copies in `.agents/skills/` and leaves unrelated `.agents/skills` content alone. If you installed the optional saga test dependency only for this package, remove it separately:

```bash
npx ag-redux-toolkit cleanup-skills
# or: npm exec -- ag-redux-toolkit cleanup-skills
```

Then remove optional test dependencies if your app does not use them elsewhere:

```bash
npm uninstall -D redux-saga-test-plan
```

If the package has already been uninstalled and the cleanup script is no longer available, remove only copied package-owned skill files and folders you no longer need, such as `.agents/skills/SKILL.md`, `.agents/skills/svelte`, `.agents/skills/core`, `.agents/skills/streaming`, and legacy package-owned folders from older `svelte-redux-toolkit` installs (`.agents/skills/svelte-redux-toolkit`, `.agents/skills/init-svelte-redux-toolkit`, `.agents/skills/migrate-to-svelte-redux-toolkit`). Do not delete `.agents/skills` wholesale if it contains skills from other packages or your project.

## Quick start

Choose the Store variant that matches how callers consume selectors. All variants take app-owned reducer maps in the constructor, initialize once before use, and start each app saga explicitly by function with `store.runSaga(sagaFn)`.

### Public import paths

Use the public subpackage entrypoints in application code. Utility modules that are intentionally public also have explicit leaf subpaths; there is no package root or `ag-redux-toolkit/utils` barrel.

| Subpackage | Use for |
| --- | --- |
| ag-redux-toolkit/svelte-store | Canonical Svelte-readable Store class. Use the configured Store instance for per-store operations such as init, dispatch, state reads, selectors, and saga startup. Utility helpers are not exported here; use the explicit utility leaf subpaths below. |
| ag-redux-toolkit/streaming-store | Kefir/observable StreamingStore. Its createSelector(...) calls return streaming selector results instead of Svelte readables. |
| ag-redux-toolkit/react-store | ReactStore for React UIs. Its createSelector(...) calls return Preact React signals directly and expose `.use(...args)` for React component reads. |
| ag-redux-toolkit/saga | Saga authoring helpers, selector-channel effects, retry/timeout utilities, and streaming helpers. |
| ag-redux-toolkit/types | Public TypeScript types |
| ag-redux-toolkit/components-svelte/use-init-store, /use-run-saga | Optional Svelte lifecycle helper leaf imports. There is no components compatibility path or components-svelte barrel. |
| ag-redux-toolkit/utils/collections/collection-utils | Direct collection utility access when a package-level leaf import is needed. |
| ag-redux-toolkit/utils/store/create-action, /create-reducer, /boolean-preference, /domain-scoped | The only package-level store utility leaf imports. |
| ag-redux-toolkit/utils/sagas/<leaf> | Approved saga utility leaves: debounce-saga, retry-with-timeout, wrap-async-generator, and selector-channel-effects. Safe localStorage helpers are example/app-local utilities, not package exports. |

Migration note: replace old flat package-root imports, removed utilities-subpackage imports, and source-shaped deep imports with one of the public subpackages or approved utility leaf subpaths above. The package does not publish a root runtime API or `utils` directory barrel; choose the explicit subpath that owns the API.

### Which Store variant should I use?

- Use `Store` from `ag-redux-toolkit/svelte-store` in Svelte/SvelteKit apps when direct selector calls should return Svelte `Readable` values for `$selector` and `subscribe(...)` component usage.
- Use `ReactStore` from `ag-redux-toolkit/react-store` in React apps when direct selector calls should return Preact React `ReadonlySignal` values and React components should read plain values with `.use(...args)`.
- Use `StreamingStore` from `ag-redux-toolkit/streaming-store` for Node, server, worker, CLI, tests, or other non-Svelte consumers when direct selector calls should return Kefir `Observable` streams.
- All concrete Store constructors share the same shape: `new Store(reducersMap?, middleware?, options?)`, `new ReactStore(reducersMap?, middleware?, options?)`, and `new StreamingStore(reducersMap?, middleware?, options?)`. When you do not have middleware but need options, pass `undefined` as the second argument and put options last. The final options object is also where Store-owned diagnostics live; enable optional saga monitoring with `{ sagaMonitor: true }` or selector trace output with `{ traceSelectors: true }` only when diagnosing runtime behavior.

### Svelte-readable setup

```svelte
<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { Store } from 'ag-redux-toolkit/svelte-store';
  import { counterReducer } from './slices/counter/counter-slice';
  import { counterSaga } from './slices/counter/sagas/counter-saga';

  const store = new Store(
    { counter: counterReducer },
    undefined,
    { throttledSelectorFrequency: 64, sagaMonitor: true }
  );

  const dispose = store.init();
  onDestroy(dispose);

  onMount(() => store.runSaga(counterSaga));
</script>
```

### Streaming/non-Svelte setup

```ts
import { StreamingStore } from 'ag-redux-toolkit/streaming-store';
import { counterReducer } from './slices/counter/counter-slice';
import { counterSaga } from './slices/counter/sagas/counter-saga';

const streamStore = new StreamingStore(
  { counter: counterReducer },
  undefined,
  { throttledSelectorFrequency: 64 }
);

const dispose = streamStore.init();
const cancelCounterSaga = streamStore.runSaga(counterSaga);

const selectCount = streamStore.createSelector((state) => state.counter.count);
const countSubscription = selectCount().observe((count) => {
  console.log(count);
});

countSubscription.unsubscribe();
cancelCounterSaga();
dispose();
```

`StreamingStore` selectors return Kefir observables from direct calls, while `.select(state, ...args)` remains available for synchronous reads and `.effect(...args)` remains available inside sagas.

### React signal setup

```tsx
import { ReactStore } from 'ag-redux-toolkit/react-store';
import { counterReducer } from './slices/counter/counter-slice';
import { counterSaga } from './slices/counter/sagas/counter-saga';

const reactStore = new ReactStore(
  { counter: counterReducer },
  undefined,
  { throttledSelectorFrequency: 64 }
);

const dispose = reactStore.init();
const cancelCounterSaga = reactStore.runSaga(counterSaga);

const selectCount = reactStore.createSelector((state) => state.counter.count);
const countSignal = selectCount();
console.log(countSignal.value);

function CounterLabel() {
  const count = selectCount.use();
  return <span>{count}</span>;
}

cancelCounterSaga();
dispose();
```

`ReactStore` selectors return `ReadonlySignal<R>` values from direct calls for signal-aware code. In React components or custom hooks, call `selectFoo.use(...args)` to receive the current plain `R` value and subscribe through the Preact signals React integration; this path is throttled by the Store's `throttledSelectorFrequency` just like direct signal output. Use `.effect(...args)` only from sagas; it creates a typed-redux-saga select effect and is not a React hook or signal subscription.

Selector trace output is also disabled by default. Pass `{ traceSelectors: true }` in the final Store options object only when you need temporary selector scheduling diagnostics; omit it or pass `false` for normal silent selector behavior.

Package-owned internals are managed automatically under reserved `@internal_` names. Internal reducers such as `@internal_storeUtility` are package-managed, and the internal saga manager starts during `Store` initialization. Do not register `@internal_` reducers or start internal sagas yourself, and do not read those internal state domains directly from app code.

When you need the app state type, infer it from the configured `Store` instance:

```ts
import { Store } from 'ag-redux-toolkit/svelte-store';
import type { StoreInstanceState } from 'ag-redux-toolkit/types';
import { counterReducer } from './slices/counter/counter-slice';

export const store = new Store({ counter: counterReducer });
export type AppState = StoreInstanceState<typeof store>;
```

The constructor reducer map drives `StoreInstanceState<typeof store>` inference. Normal setup does not require an explicit `: Store` annotation. `StoreState<typeof store>` remains supported for state typing. The final constructor argument accepts Store options such as `{ throttledSelectorFrequency: 64, sagaMonitor: true, traceSelectors: true }`. `throttledSelectorFrequency` controls selector emission coalescing in Svelte-readable Store, ReactStore, and StreamingStore selectors; omit it for the default `64` FPS, or provide any finite value in the inclusive `1..256` range. `sagaMonitor: true` enables Store-owned redux-saga monitoring, and `traceSelectors: true` enables selector trace output; both diagnostics are disabled by default and stay disabled when omitted or set to `false`. Do not monkey-patch or replace the Store's saga middleware just to observe saga effects. The inferred state type includes package-owned `@internal_` domains for completeness; treat those as implementation details and read app-owned slices through selectors. `Store` is the canonical Svelte-readable class from `ag-redux-toolkit/svelte-store`; use `ReactStore` from `ag-redux-toolkit/react-store` when selector calls should return Preact React signals; use `StreamingStore` from `ag-redux-toolkit/streaming-store` when selector calls should return Kefir streams.

Call `store.init(initialState?)` during root component initialization and register the returned disposer with Svelte `onDestroy`. The returned disposer delegates to `store.dispose()`, so `onDestroy(dispose)` remains the preferred root-layout pattern; direct `store.dispose()` is available when non-component code or tests own the whole Store lifetime. Store disposal tears down the initialized context and stops saga tasks owned by that context. Initialization prepares the Redux store and starts the internal saga manager, but it does **not** auto-start app sagas.

Start sagas by function through the configured `Store` instance. In Svelte components/layouts, call `store.runSaga(sagaFn)` from `onMount` so the returned cancel function becomes the mount cleanup; in non-component code, keep and call that cancel function yourself:

```ts
const cancelCounterSaga = store.runSaga(counterSaga);
cancelCounterSaga();
```

## Why Svelte-readable usage feels good in Svelte

- **Selectors feel native to Svelte.** In the Svelte-readable usage path, `Store` selectors return Svelte readables, so components can subscribe naturally while `.select(state, ...args)` serves non-component code and `.effect(...args)` serves sagas.
- **Selector updates stay smooth.** Svelte-readable selector emissions are capped and coalesced to around frame rate (about 64fps), keeping fast Redux or readable argument updates from turning into noisy UI work.
- **Cached values stay precise.** Selector caching uses proxy tracking for exactly the state paths read, so unrelated store changes do not have to invalidate derived values.
- **That combination is the fit.** Default readables, frame-friendly emissions, and path-aware caching are the main reason the toolkit works especially well in Svelte.
- **Components stay focused on UI.** Shared state transitions live in reducers, and async work lives in sagas.
- **Workflows are explicit.** Sagas are started through `store.runSaga(sagaFn)` after initialization and stopped by the returned cancel function or by full Store teardown through `store.dispose()`.
- **State stays easy to inspect.** Redux state, explicit action flow, and console inspection tools make behavior easier to trace than ad hoc component side effects.

## Learn more

The package includes focused reference docs and agent skills for deeper workflows:

Ownership convention: `docs/` is the human-facing source of truth for concepts,API summaries, tradeoffs, and examples. `skills/` is concise agent-facingexecution guidance: routing, must-follow rules, pitfalls, verification cues, andlinks back to the relevant docs or source instead of duplicating longexplanations. When they diverge, update the docs/source first and keep the skillas a short operational pointer.

- `docs/ARCHITECTURE.md` — store setup, data flow, selector tracking, and saga lifecycle.
- `docs/INSTALLATION.md` — manual Skills installation, cleanup/uninstall behavior, and maintainer validation.
- `docs/SELECTORS.md` — selector creation, memoization, component reads, non-component reads, and saga usage.
- `docs/SAGAS.md` — typed saga patterns for async workflows.
- `docs/COLLECTIONS.md` — normalized entity state helpers.
- `docs/TESTING.md` — reducer, selector, and saga testing strategies.
- `skills/SKILL.md` — root router for choosing Core, Svelte, React, or Streaming skill families by task path and environment evidence.
- `skills/core/` — framework-independent Redux and redux-saga agent guidance.
- `skills/svelte/` — repeatable Svelte-specific agent execution guidance.
- `skills/react/` — ReactStore and Preact signal selector guidance.
- `skills/streaming/` — StreamingStore and Kefir/observable selector guidance.
- `skills/setup/` — canonical greenfield setup workflow.
- `skills/svelte/migration/` — migration workflow for existing Svelte state.

## Maintainer validation

For this repository, use `npm ci` from a clean checkout to reproduce the committed dependency baseline. Do not use consumer install or uninstall commands for maintainer validation. After dependencies are installed, run:

```bash
npm run validate:architecture
npm test
npm run build
npm run validate:release
git diff --check
git diff --cached --check # when staged changes exist
git status --short
```

Run `npm run validate:architecture` whenever a change touches Redux state,actions, selectors, sagas, component/store imports, localStorage persistence, ortheir skills/docs. Passing means the architecture command exits 0 and prints`[architecture-validation] no architecture gate violations found`. The modulargate set checks duplicate/canonical owners plus import boundaries, namespacedaction types, serializable Redux state, safe localStorage helper usage, sagawatcher typing, named saga selector usage, RTK/shared Svelte-store boundaries,collection state shape and internal mutations, runtime state serialization,reducer purity, conservative component lifecycle/store access, pass-throughwrapper cleanup, selector call modes, typed-redux-saga `yield*` style, channellifecycle cleanup, file-structure naming, and high-signal test-pattern hygiene.If test-pattern validation fails, read the `Why:` and `How to fix:` lines: selector tests should use `selectFoo.select(mockState, ...args)`,and `vi.mock("typed-redux-saga")` call mocks must keep an`Array.isArray(fnOrDescriptor)` branch for tuple descriptors. Intentional badMarkdown examples must be clearly labeled as wrong/bad or carry a narrow reviewedstandard ESLint disable such as `// eslint-disable-next-line ag-redux-toolkit/<rule-id> -- reason` or `/* eslint-disable ag-redux-toolkit/<rule-id> -- reason */`.Noisy semantic adequacy checks remain verifier-guided rather than brittle CI.`npm run validate:release` runs the architecture gate first, then builds, checks`npm pack --dry-run --json` contents, and smoke-tests the public `/eslint-plugins` API, verifies removed `/eslint-architecture` aliases stay blocked, publicsubpackages, and approved utility leaf subpaths while ensuring the root runtime entry,source-shaped deep imports, internal utility paths, and removed subpackage exports stay unavailable. Known diagnostics that stillexit 0, such as existing `vite-plugin-dts` messages, must be reported asnon-blocking; unrelated `pnpm-lock.yaml` changes stay out of scope unless thetask explicitly approves package-manager work.

## License

MIT