import { staticString } from "../ast-utils.mjs";
import { createArchitectureRule, createArchitectureRulePlugin } from "../rule-utils.mjs";

export const ruleId = "forbidden-component-import";

function componentImportMessage(sourcePath) {
  if (sourcePath === "typed-redux-saga" || sourcePath === "redux-saga" || sourcePath.startsWith("redux-saga/")) {
    return "Components must not import saga effect libraries; dispatch actions or read selectors instead.";
  }
  if (/(^|\/)sagas?\//.test(sourcePath) || /(^|\/)[^/]*-saga(?:\.[cm]?[jt]sx?)?$/.test(sourcePath)) {
    return "Components must not import saga source; dispatch actions instead.";
  }
  if (/(?:(?:^|\/)(?:collection-utils|create-reducer)(?:$|\.)|(?:^|\/)redux-dispatch-bridge(?:$|\/))/.test(sourcePath)) {
    return "Components must not import collection, reducer, or removed bridge internals.";
  }
  return undefined;
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "Component imported a forbidden implementation boundary.",
  why: "Components should depend on actions, selectors, and store-facing APIs so saga, reducer, and collection internals remain replaceable.",
  fix: "Remove the component import of saga/reducer/collection internals and dispatch an action or read a selector instead.",
  create(_context, { classifyPath, report }) {
    return {
      ImportDeclaration(node) {
        if (!classifyPath().isSvelteComponent) return;
        const sourcePath = staticString(node.source);
        const summary = componentImportMessage(sourcePath ?? "");
        if (summary) report({ node: node.source, summary });
      },
    };
  },
});

export const plugin = createArchitectureRulePlugin(ruleId, rule);
export default plugin;