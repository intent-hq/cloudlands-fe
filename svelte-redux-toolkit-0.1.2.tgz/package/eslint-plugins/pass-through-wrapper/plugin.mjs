import { calleeIdentifierName, exportedDeclaration, unwrapExpression } from "../ast-utils.mjs";
import { createArchitectureRule } from "../rule-utils.mjs";

export const ruleId = "pass-through-wrapper";

function isPassThroughProgram(program) {
  const body = program.body.filter((node) => node.type !== "EmptyStatement");

  // Pure re-export wrappers are actionable even when there are multiple export
  // statements, because they hide the canonical owner after refactors.
  if (body.length > 0 && body.length <= 2 && body.every((node) => (node.type === "ExportAllDeclaration" || node.type === "ExportNamedDeclaration") && node.source)) {
    return body[0];
  }

  if (body.length !== 2 || body[0].type !== "ImportDeclaration") return undefined;

  const imported = body[0].specifiers.find((specifier) => specifier.type === "ImportSpecifier")?.local?.name;
  const exported = exportedDeclaration(body[1]);
  if (!imported || !exported) return undefined;

  if (exported.type === "FunctionDeclaration") {
    const statement = exported.body?.body?.[0];
    if (statement?.type === "ReturnStatement" && calleeIdentifierName(statement.argument) === imported) return exported;
  }

  if (exported.type === "VariableDeclaration") {
    const init = exported.declarations[0]?.init;
    const bodyNode = unwrapExpression(init)?.body;
    if (init?.type === "ArrowFunctionExpression" && calleeIdentifierName(bodyNode) === imported) return exported;
  }

  return undefined;
}

export const rule = createArchitectureRule({
  ruleId,
  summary: "File is only a pass-through wrapper or re-export.",
  why: "Leftover wrappers hide the canonical owner after refactors and keep stale compatibility surfaces alive.",
  fix: "Remove the wrapper or add a reviewed ESLint disable comment with compatibility and sunset/removal details.",
  create(_context, { classifyPath, report }) {
    return {
      Program(node) {
        const path = classifyPath().path;
        if (/(^|\/)index\.[cm]?[jt]sx?$/.test(path) || /-types\.[cm]?[jt]sx?$/.test(path)) return;

        const target = isPassThroughProgram(node);
        if (!target) return;

        report({
          node: target,
          summary: "Pass-through wrappers/re-exports must be removed after refactors, or kept only with a rule-specific ESLint disable reason documenting compatibility and sunset/removal conditions.",
        });
      },
    };
  },
});

export const plugin = {
  meta: { name: `svelte-redux-toolkit/architecture/pass-through-wrapper`, version: "0.1.0" },
  rules: { [ruleId]: rule },
};
export default plugin;
