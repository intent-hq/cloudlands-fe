#!/usr/bin/env node

/**
 * install-skills helper — copies packaged AI skills into a target project.
 *
 * Safety guarantees:
 *  - Writes only under the consumer project root's .agents/skills/ directory
 *  - Removes stale package-owned skill files before copying current files
 *  - Preserves unrelated user-authored skill directories
 *  - Excludes generated skills/_artifacts content
 *  - No-op when run outside node_modules (e.g. during the package's own npm install)
 *  - Never crashes — logs warnings and exits 0
 */

import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  rmSync,
  rmdirSync,
} from "node:fs";
import { dirname, isAbsolute, relative, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
export const defaultPackageRoot = resolve(__dirname, "..");

export function isSameOrChild(parent, child) {
  const relativePath = relative(parent, child);
  return relativePath === "" || (!relativePath.startsWith("..") && !isAbsolute(relativePath));
}

function hasNodeModulesSegment(path) {
  return resolve(path).split(sep).includes("node_modules");
}

function nearestNodeModulesOwner(path) {
  const segments = resolve(path).split(sep);
  const nodeModulesIndex = segments.lastIndexOf("node_modules");
  return nodeModulesIndex > 0 ? segments.slice(0, nodeModulesIndex).join(sep) : undefined;
}

export function findConsumerProjectRoot({ packageRoot = defaultPackageRoot, env = process.env } = {}) {
  const resolvedPackageRoot = resolve(packageRoot);
  const initCwd = env.INIT_CWD ? resolve(env.INIT_CWD) : undefined;

  if (initCwd && isSameOrChild(initCwd, resolvedPackageRoot) && hasNodeModulesSegment(relative(initCwd, resolvedPackageRoot))) {
    return initCwd;
  }

  return nearestNodeModulesOwner(resolvedPackageRoot);
}

export function isGeneratedSkillArtifact(path, skillsRoot) {
  const relativePath = relative(skillsRoot, path);
  return relativePath === "_artifacts" || relativePath.startsWith(`_artifacts${sep}`);
}

function safeResolveChild(parent, ...segments) {
  const resolvedParent = resolve(parent);
  const child = resolve(resolvedParent, ...segments);
  if (!isSameOrChild(resolvedParent, child)) {
    throw new Error(`Refusing to write outside ${resolvedParent}`);
  }
  return child;
}

export function getPackagedSkillInventory(skillsRoot) {
  const files = new Map();
  const skillNames = [];

  function collect(currentPath) {
    if (isGeneratedSkillArtifact(currentPath, skillsRoot)) return;

    const stat = lstatSync(currentPath);
    if (stat.isDirectory() && !stat.isSymbolicLink()) {
      for (const entry of readdirSync(currentPath)) {
        collect(resolve(currentPath, entry));
      }
      return;
    }

    if (stat.isFile()) {
      files.set(relative(skillsRoot, currentPath), currentPath);
    }
  }

  for (const entry of readdirSync(skillsRoot)) {
    const entryPath = resolve(skillsRoot, entry);
    if (isGeneratedSkillArtifact(entryPath, skillsRoot)) continue;
    skillNames.push(entry);
    collect(entryPath);
  }

  return { files, skillNames };
}

function filesAreEqual(left, right) {
  if (!existsSync(right)) return false;
  const rightStat = lstatSync(right);
  if (!rightStat.isFile()) return false;
  return readFileSync(left).equals(readFileSync(right));
}

export function removePackageOwnedSkillCopies({ skillsDest, packagedFiles, skillNames, removeCurrent = false } = {}) {
  if (!existsSync(skillsDest)) return { removed: 0, pruned: 0 };

  let removed = 0;
  let pruned = 0;

  function clean(currentPath) {
    const relativePath = relative(skillsDest, currentPath);
    if (relativePath.startsWith("..") || isAbsolute(relativePath)) return;

    const stat = lstatSync(currentPath);
    if (stat.isDirectory() && !stat.isSymbolicLink()) {
      for (const entry of readdirSync(currentPath)) {
        clean(resolve(currentPath, entry));
      }

      if (readdirSync(currentPath).length === 0) {
        rmdirSync(currentPath);
        pruned += 1;
      }
      return;
    }

    if (removeCurrent || !packagedFiles.has(relativePath)) {
      rmSync(currentPath, { force: true });
      removed += 1;
    }
  }

  for (const skillName of skillNames) {
    const skillDest = safeResolveChild(skillsDest, skillName);
    if (existsSync(skillDest)) clean(skillDest);
  }

  return { removed, pruned };
}

export function copyPackagedSkillsToProject({ packageRoot = defaultPackageRoot, projectRoot, logger = console } = {}) {
  const resolvedProjectRoot = projectRoot ?? findConsumerProjectRoot({ packageRoot });
  if (!resolvedProjectRoot) {
    logger.log(
      "[svelte-redux-toolkit] install-skills skipped: package is not installed under a consumer node_modules directory; no skill files were copied."
    );
    return { installed: false, skipped: true, reason: "not-installed-dependency" };
  }

  const skillsSrc = resolve(packageRoot, "skills");
  if (!existsSync(skillsSrc)) {
    logger.log("[svelte-redux-toolkit] install-skills skipped: packaged skills were not found; no skill files were copied.");
    return { installed: false, skipped: true, reason: "missing-skills", projectRoot: resolvedProjectRoot };
  }

  const skillsDest = safeResolveChild(resolvedProjectRoot, ".agents", "skills");
  const inventory = getPackagedSkillInventory(skillsSrc);
  mkdirSync(skillsDest, { recursive: true });

  const cleanup = removePackageOwnedSkillCopies({
    skillsDest,
    packagedFiles: inventory.files,
    skillNames: inventory.skillNames,
  });

  let copied = 0;
  let updated = 0;
  let unchanged = 0;

  for (const [relativePath, sourcePath] of inventory.files) {
    const destPath = safeResolveChild(skillsDest, relativePath);
    mkdirSync(dirname(destPath), { recursive: true });

    if (filesAreEqual(sourcePath, destPath)) {
      unchanged += 1;
      continue;
    }

    const existed = existsSync(destPath);
    if (existed) rmSync(destPath, { recursive: true, force: true });
    copyFileSync(sourcePath, destPath);
    if (existed) updated += 1;
    else copied += 1;
  }

  logger.log(
    `[svelte-redux-toolkit] install-skills copied packaged skills to .agents/skills/ (${copied} copied, ${updated} updated, ${unchanged} unchanged, ${cleanup.removed} stale removed, ${cleanup.pruned} empty dirs pruned).`
  );

  return {
    installed: copied > 0 || updated > 0,
    skipped: copied === 0 && updated === 0 && cleanup.removed === 0 && cleanup.pruned === 0,
    projectRoot: resolvedProjectRoot,
    destination: skillsDest,
    copied,
    updated,
    unchanged,
    removed: cleanup.removed,
    pruned: cleanup.pruned,
  };
}

export function installIntentSkillGuidance({
  packageRoot = defaultPackageRoot,
  projectRoot,
  env = process.env,
  logger = console,
} = {}) {
  const resolvedProjectRoot = projectRoot ?? findConsumerProjectRoot({ packageRoot, env });
  return copyPackagedSkillsToProject({ packageRoot, projectRoot: resolvedProjectRoot, logger });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    installIntentSkillGuidance();
  } catch (err) {
    console.warn(`[svelte-redux-toolkit] install-skills warning: ${err.message}`);
    process.exit(0);
  }
}

